import { formatCurrency } from './calculations';
import {
  PayScheduleConfig, getRemainingTransactionIncomeByDay, getRemainingTransactionExpensesByDay,
  getRemainingIncomeByDay, getRemainingExpensesByDay, getRemainingNonPaycheckIncomeByDay,
  buildPayConfig, getPrePaycheckNextMonthBills, getMonthNetIncome,
} from './pay-schedule';
import { countRuleOccurrencesInMonth } from './scheduling';

export type CardData = {
  id: string;
  name: string;
  balance: number;
  apr: number;
  creditLimit: number;
  minPayment: number;
  targetPayment: number;
  monthlyNewPurchases: number;
  monthlyRepayments: number;
  color: string;
  paymentPreference: 'statement' | 'full' | null;
  autopayFullBalance: boolean;
  dueDay: number | null;
  startDate?: string;
  statementBalancePhase: boolean;
  statementBalance: number | null;
};

export type CardMonthRow = {
  month: number;
  label: string;
  startBalance: number;
  newPurchases: number;
  interest: number;
  payment: number;
  endBalance: number;
  utilization: number;
};

export type CardProjection = {
  card: CardData;
  months: CardMonthRow[];
  payoffMonth: number | null;
  totalInterest: number;
  projectedInterestThisMonth: number;
  recommendedPayment: number;
  utilizationNow: number;
};

export type PayoffRecommendation = {
  cardId: string;
  cardName: string;
  color: string;
  payment: number;
  isMinimumOnly: boolean;
  reason: string;
  estimatedLiquidCash?: number;
  dueDay?: number | null;
};

export type RecommendationSummary = {
  totalAvailableCash: number;
  totalMinimumsdue: number;
  extraCashAvailable: number;
  recommendations: PayoffRecommendation[];
  interestAvoided: number;
  projectedPayoffMonths: number;
  utilizationMilestones: { threshold: number; month: number | null }[];
  cashWarning: boolean;
  strategyLabel: string;
  recommendedSafeMinimum: number;
  userCashFloor: number;
  prePaycheckBills: number;
  breakdown: {
    fundingBalance: number;
    remainingPaycheckIncome: number;
    remainingNonPaycheckIncome: number;
    remainingOneTimeIncome: number;
    remainingExpenses: number;
    remainingOneTimeExpenses: number;
    safeMinimum: number;
    autopayTotal: number;
  };
};

const CARD_COLORS = [
  'hsl(200, 70%, 55%)', 'hsl(280, 55%, 55%)', 'hsl(340, 65%, 50%)',
  'hsl(160, 55%, 45%)', 'hsl(30, 70%, 50%)', 'hsl(60, 55%, 50%)',
];

export const CC_DEFAULT_CATEGORIES = new Set([
  'Groceries', 'Subscriptions', 'Pets', 'Dining', 'Gas', 'Entertainment',
  'Travel', 'Shopping', 'Miscellaneous', 'Other', 'Personal', 'Clothing',
  'Health', 'Fitness', 'Gifts', 'Education',
]);

export const BANK_DEFAULT_CATEGORIES = new Set([
  'Bills', 'Rent', 'Mortgage', 'Utilities', 'Internet', 'Insurance',
  'Debt Payments', 'Transfers', 'Investing', 'Savings',
]);

export function getCardColor(index: number): string {
  return CARD_COLORS[index % CARD_COLORS.length];
}

export function calcMinPayment(balance: number, apr: number): number {
  if (balance <= 0) return 0;
  const interestCharge = (balance * (apr / 100)) / 12;
  const pctMin = balance * 0.01;
  return Math.max(25, Math.ceil(interestCharge + pctMin));
}

export function getDefaultCardForExpense(category: string, accounts: any[]): string | null {
  if (!CC_DEFAULT_CATEGORIES.has(category)) return null;
  const activeCards = accounts
    .filter((a: any) => a.account_type === 'credit_card' && a.active)
    .sort((a: any, b: any) => (Number(b.apr) || 0) - (Number(a.apr) || 0));
  return activeCards.length > 0 ? `account:${activeCards[0].id}` : null;
}

export function buildCardData(
  accounts: any[], transactions: any[], rules: any[], debts: any[], colorStartIndex = 0,
): CardData[] {
  if (!accounts || !transactions || !rules || !debts) return [];
  const ccAccounts = accounts.filter((a: any) => a.account_type === 'credit_card' && a.active);

  return ccAccounts.map((acct, i) => {
    const acctKey = `account:${acct.id}`;
    const now = new Date();
    // Only count CC transactions in the CURRENT month from TODAY forward.
    // Past purchases are already in the card's live balance.
    // Future-month one-time purchases must NOT be summed here — they are
    // attributed per-month via cardPurchasesPerMonth in the simulation.
    const todayStr = now.toISOString().split('T')[0];
    const currentMonthStr = todayStr.slice(0, 7); // 'YYYY-MM'
    const monthPurchases = transactions
      .filter((t: any) =>
        t.type === 'expense' &&
        (t.payment_source === acctKey || t.payment_source === acct.id) &&
        t.date >= todayStr &&
        t.date.startsWith(currentMonthStr),
      )
      .reduce((s: number, t: any) => s + Number(t.amount), 0);

    // Use next month (full month, no today-cutoff) so monthlyNewPurchases represents a
    // complete billing cycle. The current month is partial — most recurring bills already
    // fired and are baked into the live balance, so using it understates future monthly
    // spending and causes the projection to flatline at whatever charges remain this month.
    const projRef = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    const recurringExplicit = rules
      .filter((r: any) => r.active && r.rule_type === 'expense' && (r.payment_source === acctKey || r.payment_source === acct.id))
      .reduce((s: number, r: any) =>
        s + Number(r.amount) * countRuleOccurrencesInMonth(r, projRef.getFullYear(), projRef.getMonth()),
      0);

    const highestAprCard = [...ccAccounts].sort((a: any, b: any) => (Number(b.apr) || 0) - (Number(a.apr) || 0))[0];
    const isDefaultCard = highestAprCard?.id === acct.id;

    const recurringDefault = isDefaultCard ? rules
      .filter((r: any) => r.active && r.rule_type === 'expense' && !r.payment_source && CC_DEFAULT_CATEGORIES.has(r.category))
      .reduce((s: number, r: any) =>
        s + Number(r.amount) * countRuleOccurrencesInMonth(r, projRef.getFullYear(), projRef.getMonth()),
      0) : 0;

    const monthlyNewPurchases = Math.max(monthPurchases, recurringExplicit + recurringDefault);

    const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
    const monthRepayments = transactions
      .filter((t: any) => t.type === 'expense' && t.category === 'Debt Payments' && t.note?.toLowerCase().includes(acct.name.toLowerCase()) && t.date >= monthStart)
      .reduce((s: number, t: any) => s + Number(t.amount), 0);

    const matchDebt = debts.find((d: any) => d.name.toLowerCase() === acct.name.toLowerCase());
    const balance = Number(acct.balance);
    const apr = Number(acct.apr) || 0;
    const creditLimit = Number(acct.credit_limit) || 0;
    // Use accounts.min_payment (Plaid-synced or user-set via Accounts tab) as source of truth.
    // Fall back to debts table, then $25 if neither has a stored value.
    // Never recalculate from balance — the stored static value is what's actually due.
    const acctMin = acct.min_payment != null ? Number(acct.min_payment) : null;
    const minPay = (acctMin != null && acctMin > 0)
      ? acctMin
      : matchDebt && Number(matchDebt.min_payment) > 0
        ? Number(matchDebt.min_payment)
        : 25;
    const targetPay = matchDebt ? Number(matchDebt.target_payment) : minPay;

    const pref = (acct as any).payment_preference;
    const paymentPreference: 'statement' | 'full' | null =
      pref === 'statement' ? 'statement' : pref === 'full' ? 'full' : null;
    const statementBalancePhase = Boolean((acct as any).statement_balance_phase);
    const statementBalance = (acct as any).statement_balance != null ? Number((acct as any).statement_balance) : null;
    const simBalance = statementBalance !== null ? statementBalance : balance;
    const autopayFullBalance = simBalance <= 0;

    return {
      id: acct.id, name: acct.name, balance: simBalance, apr, creditLimit,
      minPayment: minPay,
      targetPayment: Math.max(targetPay, minPay),
      monthlyNewPurchases, monthlyRepayments: monthRepayments,
      color: getCardColor(colorStartIndex + i),
      paymentPreference, autopayFullBalance,
      dueDay: (acct as any).payment_due_day ?? null,
      startDate: (acct as any).card_start_date || undefined,
      statementBalancePhase, statementBalance,
    };
  });
}

/** Project a single card with FIXED payment (consistent mode or standalone view) */
export function projectCard(card: CardData, months = 36): CardProjection {
  const rows: CardMonthRow[] = [];
  let bal = card.balance;
  let totalInterest = 0;
  let payoffMonth: number | null = null;
  const monthlyRate = card.apr / 100 / 12;
  const simMonths = Math.max(months, 360); // run far past display window so payoffMonth is found even when sim gives 0 payments early on
  // Grace period: true when last payment covered full statement balance, so new purchases don't accrue interest
  let inGrace = card.paymentPreference === 'statement' && (card.statementBalancePhase || card.balance <= card.monthlyNewPurchases + 0.01);
  // Billing cycle deferred payment: autopay card charges in month m are paid in month m+1.
  let prevMonthPurchases = 0;

  for (let m = 1; m <= simMonths; m++) {
    if (payoffMonth !== null) break;
    const d = new Date();
    d.setMonth(d.getMonth() + m - 1);
    const label = d.toLocaleString('en', { month: 'short', year: 'numeric' });
    const startBal = bal;
    const newPurchases = card.monthlyNewPurchases;

    if (card.autopayFullBalance && bal <= 0) {
      const startBal = prevMonthPurchases; // previous month's unpaid charges
      const payment = prevMonthPurchases;  // payment clears last month's statement
      prevMonthPurchases = newPurchases;
      const endBal = newPurchases; // this month's charges, paid next cycle
      const utilization = card.creditLimit > 0 ? (endBal / card.creditLimit) * 100 : 0;
      if (m <= months) rows.push({ month: m, label, startBalance: startBal, newPurchases, interest: 0, payment, endBalance: endBal, utilization });
      continue;
    }

    const interest = (card.paymentPreference === 'statement' && inGrace)
      ? 0
      : Math.round(Math.max(0, bal) * monthlyRate * 100) / 100;
    const payment = bal <= 0 ? 0 : Math.min(card.targetPayment, bal + newPurchases + interest);
    if (card.paymentPreference === 'statement') inGrace = payment >= startBal + interest - 0.01;
    bal = startBal + newPurchases + interest - payment;
    totalInterest += interest;
    const utilization = card.creditLimit > 0 ? (Math.max(0, bal) / card.creditLimit) * 100 : 0;
    if (m <= months) rows.push({ month: m, label, startBalance: Math.round(startBal * 100) / 100, newPurchases, interest, payment, endBalance: Math.round(bal * 100) / 100, utilization });
    if (payoffMonth === null && startBal > 0) {
      if (card.paymentPreference === 'statement') {
        // "interest-free" = carried balance fully cleared; balance at or below rolling purchases
        if (bal <= card.monthlyNewPurchases + 0.01) payoffMonth = m;
      } else if (bal <= 0) {
        payoffMonth = m;
      }
    }
  }

  return {
    card, months: rows, payoffMonth, totalInterest: Math.round(totalInterest),
    projectedInterestThisMonth: rows[0]?.interest || 0,
    recommendedPayment: (card.autopayFullBalance && card.balance <= 0) ? card.monthlyNewPurchases : card.targetPayment,
    utilizationNow: card.creditLimit > 0 ? (card.balance / card.creditLimit) * 100 : 0,
  };
}

export function projectCardVariable(
  card: CardData,
  monthlyPayments: number[],
  months = 36,
  /**
   * When true, month 1 uses 0 purchases instead of card.monthlyNewPurchases.
   * Set this when monthlyPayments comes from simulateVariablePayoff, whose month 0
   * (= rest of current month) uses 0 purchases because the live card balance already
   * includes current-month spending. Without this flag the running balance diverges
   * from the sim by exactly one month of purchases, causing cards to appear to never
   * reach $0 in the projection table.
   */
  skipFirstMonthPurchases = false,
  /**
   * Optional per-month purchase amounts for this card (index = m-1, same as monthlyPayments).
   * When provided, overrides card.monthlyNewPurchases so one-time CC transactions are
   * reflected in the Purchases column of the projection table.
   * purchasesPerMonth[0] corresponds to projection month 1 (sim month 0) — should be 0.
   * purchasesPerMonth[1] corresponds to projection month 2 (sim month 1), etc.
   */
  purchasesPerMonth?: number[],
  /**
   * Sim-computed revolving balances per month (index = m-1) from simulateVariablePayoff.
   * When provided, revolvingBalances[m-1] === 0 is used as ground truth to detect when a
   * card has cleared its revolving debt and should enter cycling mode. This avoids the
   * ~$0.01 rounding drift in the local `inGrace` check that prevents statement-preference
   * cards from ever setting payoffMonth.
   */
  revolvingBalances?: number[],
  /**
   * Sim-computed true amount owed at the start of each cycling billing cycle (index = m-1),
   * before that month's payment — includes any interest carried from a missed full payment.
   * When provided, used for the cycling row's startBalance/endBalance so a partial payment is
   * visible in the row where it happens instead of silently disappearing until next month.
   */
  cyclingOwedByMonth?: number[],
  /** Sim-computed interest charged each cycling month (index = m-1) on a carried-forward
   * unpaid balance — 0 unless the previous cycle's payment fell short of the full statement. */
  cyclingInterestByMonth?: number[],
): CardProjection {
  const rows: CardMonthRow[] = [];
  let bal = card.balance;
  let totalInterest = 0;
  let payoffMonth: number | null = null;
  const monthlyRate = card.apr / 100 / 12;
  const simMonths = Math.max(months, 360); // run far past display window so payoffMonth is found even when sim gives 0 payments early on
  let inGrace = card.paymentPreference === 'statement' && (card.statementBalancePhase || card.balance <= card.monthlyNewPurchases + 0.01);

  for (let m = 1; m <= simMonths; m++) {
    const hasPref = card.autopayFullBalance || card.paymentPreference !== null;
    // Use sim revolving balance as ground truth when available: avoids ~$0.01 rounding
    // drift in the local inGrace check that prevents statement cards from ever transitioning.
    const simRevBal = revolvingBalances?.[m - 1];
    const isCycling = hasPref && (
      simRevBal !== undefined ? simRevBal === 0 : (bal <= 0 || payoffMonth !== null)
    );

    if (!hasPref && bal <= 0 && payoffMonth !== null) break;
    if (isCycling && m > months) break;

    const d = new Date();
    d.setMonth(d.getMonth() + m - 1);
    const label = d.toLocaleString('en', { month: 'short', year: 'numeric' });
    const startBal = bal;
    const newPurchases = purchasesPerMonth?.[m - 1] !== undefined
      ? purchasesPerMonth[m - 1]
      : (m === 1 && skipFirstMonthPurchases) ? 0
      : m > monthlyPayments.length ? 0 // beyond sim range: track carried balance only; new purchases assumed paid in-cycle
      : card.monthlyNewPurchases;

    if (isCycling) {
      if (payoffMonth === null) payoffMonth = m;
      const payment = Math.round((monthlyPayments[m - 1] ?? 0) * 100) / 100;
      const trueOwedThisCycle = cyclingOwedByMonth?.[m - 1];
      const cycleStartBal = trueOwedThisCycle !== undefined ? Math.round(trueOwedThisCycle * 100) / 100 : payment;
      const cycleInterest = cyclingInterestByMonth?.[m - 1] ?? 0;
      const trueOwedNextCycle = cyclingOwedByMonth?.[m];
      const endBal = trueOwedNextCycle !== undefined ? Math.round(trueOwedNextCycle * 100) / 100 : Math.round(newPurchases * 100) / 100;
      const utilization = card.creditLimit > 0 ? (endBal / card.creditLimit) * 100 : 0;
      totalInterest += cycleInterest;
      rows.push({ month: m, label, startBalance: cycleStartBal, newPurchases, interest: cycleInterest, payment, endBalance: endBal, utilization });
      continue;
    }

    const interest = (card.paymentPreference === 'statement' && inGrace)
      ? 0
      : Math.round(Math.max(0, bal) * monthlyRate * 100) / 100;
    // Past the sim window, a cycling statement card uses purchases as the payment proxy
    // (the card pays its balance in full each cycle). Without this, minPayment=0 causes
    // 300+ months of compounding interest on the cycling balance → inflated totalInterest.
    const availablePayment = m > monthlyPayments.length && payoffMonth !== null
      ? card.monthlyNewPurchases
      : (monthlyPayments[m - 1] ?? card.minPayment);
    const payment = bal <= 0 ? 0 : Math.min(availablePayment, bal + newPurchases + interest);
    if (card.paymentPreference === 'statement') inGrace = payment >= startBal + interest - 0.01;
    bal = startBal + newPurchases + interest - payment;
    if (bal > 0 && bal < 1) bal = 0; // clear sub-dollar dust to match sim behaviour
    totalInterest += interest;
    const utilization = card.creditLimit > 0 ? (Math.max(0, bal) / card.creditLimit) * 100 : 0;
    if (m <= months) rows.push({ month: m, label, startBalance: Math.round(startBal * 100) / 100, newPurchases, interest, payment: Math.round(payment * 100) / 100, endBalance: Math.round(bal * 100) / 100, utilization });
    if (payoffMonth === null && startBal > 0) {
      if (card.paymentPreference === 'statement') {
        // inGrace = payment covered opening balance + interest this cycle,
        // meaning only new purchases remain → card is interest-free going forward.
        // This is correct regardless of whether purchasesPerMonth differs from
        // monthlyNewPurchases, and avoids false positives beyond the sim window
        // where newPurchases drops to 0.
        if (inGrace) payoffMonth = m;
      } else if (bal <= 0) {
        payoffMonth = m;
      }
    }
  }

  return {
    card, months: rows, payoffMonth, totalInterest: Math.round(totalInterest),
    projectedInterestThisMonth: rows[0]?.interest || 0,
    recommendedPayment: (card.autopayFullBalance && card.balance <= 0) ? card.monthlyNewPurchases : (monthlyPayments[0] ?? card.targetPayment),
    utilizationNow: card.creditLimit > 0 ? (card.balance / card.creditLimit) * 100 : 0,
  };
}

// ─── Simulation output types ──────────────────────────────

/** A projected debt payment emitted by simulateVariablePayoff for Forecast / Transactions rendering. */
export type SimulatedDebtPayment = {
  date: string;           // ISO date — last day of the payment month
  description: string;    // e.g. "Prime Visa Payment"
  amount: number;         // positive outflow amount
  account: string;        // funding account id ('' when unknown)
  category: 'Debt Payments';
  card: string;           // credit card account id
  type: 'debt_payoff';
  projected: true;
};

/** Flags emitted by simulateVariablePayoff describing per-month anomalies. */
export type SimulationFlag = {
  month: number;
  flag: 'UNSTABLE' | 'FLOOR_BREACHED' | 'CARD_AT_RISK';
  /** Set when flag === 'CARD_AT_RISK' — identifies which card missed its minimum. */
  cardId?: string;
};

/**
 * Event-based, cash-floor-aware variable payoff simulation.
 *
 * Algorithm (Steps 1-8, plan debt-engine-v2.md):
 *   Step 1  Initialise balances and currentCash from inputs.
 *   Step 2  Compute available cash from events (or scalar fallback).
 *   Step 3  Pay minimums; handle FLOOR_BREACHED with snowball protection.
 *   Step 4  Allocate extra cash to priority card (avalanche / snowball).
 *           C3: card balance has NOT been reduced yet — do not double-subtract.
 *   Step 5  Deduct payments from balances and currentCash.
 *   Step 6  Apply interest AFTER all payments (C4 — never mid-month).
 *   Step 7  Advance month: currentCash += monthIncome - monthExpenses.
 *   Step 8  Repeat until all balances = 0 or month limit reached.
 *
 * Backward-compatible: existing callers pass 7 positional args (scalars).
 * Event-based callers (TASK 2) additionally pass monthEvents[] and fundingAccountId.
 */
export function simulateVariablePayoff(
  cards: CardData[],
  liquidCash: number,
  cashFloor: number,
  strategy: 'avalanche' | 'snowball',
  /** Scalar fallback — used when monthEvents is not provided. */
  monthlyTakeHome: number,
  /** Scalar fallback — used when monthEvents is not provided. */
  monthlyExpenses: number,
  months = 36,
  /**
   * Optional event-based per-month income/expense sums (C5).
   * monthEvents[0]  = current month scoped today→EOM (scoped by caller, C1).
   * monthEvents[1+] = full future month sums.
   * When omitted, monthlyTakeHome / monthlyExpenses scalars are used for every month.
   */
  monthEvents?: { income: number; expenses: number }[],
  /** Used to populate the `account` field on SimulatedDebtPayment records. */
  fundingAccountId?: string,
  /**
   * Optional per-month per-card CC purchase amounts (T1/T3).
   * cardPurchasesPerMonth[m][cardId] = total CC purchases for that card in month m.
   * Month 0 should be 0 — the live card.balance already includes today's purchases.
   * When omitted, falls back to card.monthlyNewPurchases for months 1+ (legacy callers).
   */
  cardPurchasesPerMonth?: { [cardId: string]: number }[],
  /**
   * Override for month 0 (current month) remaining income from today to month-end.
   * Takes priority over monthEvents[0].income and the monthlyTakeHome scalar.
   * Derived from allTransactions so the live account balance is the ground truth.
   */
  month0RemainingIncome?: number,
  /**
   * Override for month 0 (current month) remaining expenses from today to month-end.
   * Takes priority over monthEvents[0].expenses and the monthlyExpenses scalar.
   */
  month0RemainingExpenses?: number,
  /**
   * Optional one-time (non-recurring) income and expense totals per month.
   * Applied in Step 7 AFTER debt allocation so they do not reduce availableCash
   * in prior months (prevents look-ahead cash hoarding for future large purchases).
   * oneTimeByMonth[0] is unused (month 0 is handled by month0Remaining*).
   */
  oneTimeByMonth?: { income: number; expenses: number }[],
  /**
   * Optional effective safe floor for month 0 only — overrides cashFloor for the current month.
   * Should be max(cashFloor, prePaycheckBills) so month 0 payments match recommendations.
   */
  month0SafeFloor?: number,
  /**
   * Optional per-month cap on the total debt payment allocation (revolving cards only).
   * Set to ccMinTotal for "save-up" months identified by the look-ahead pre-pass in callers.
   * Mirrors Forecast PASS 2 behavior so future-month debt projections are consistent.
   */
  maxDebtPaymentByMonth?: number[],
  /**
   * Optional per-month safe cash floor, computed via getMinSafeCash for each month.
   * When provided, replaces the constant cashFloor for months 1+.
   * Mirrors Forecast's monthMinSafe so the debt payoff floor matches the forecast floor.
   */
  cashFloorByMonth?: number[],
): {
  monthlyPayments: Map<string, number[]>;
  monthlyBalances: Map<string, number[]>;
  monthlyRevolvingBalances: Map<string, number[]>;
  /** Per-card per-month minimum payment based on projected balance — shrinks as debt is paid. */
  perCardMinPayments: Map<string, number[]>;
  /** Per-card per-month TRUE amount owed at the start of the cycling billing cycle (principal +
   * any carried interest), before that month's payment. Used by projectCardVariable so a
   * partial payment is visible in the row where it happens instead of silently disappearing. */
  monthlyCyclingOwed: Map<string, number[]>;
  /** Per-card per-month interest charged on a cycling card's carried-forward unpaid balance —
   * always 0 unless the previous cycle's payment fell short of the full statement. */
  monthlyCyclingInterest: Map<string, number[]>;
  projectedPayoffMonths: number;
  cashFloorBreaches: { month: number; endingCash: number }[];
  flags: SimulationFlag[];
  projectedCashByMonth: number[];
  debtPaymentTransactions: SimulatedDebtPayment[];
  warningMessages: { month: number; message: string }[];
} {
  if (cards.length === 0) {
    return {
      monthlyPayments: new Map(),
      monthlyBalances: new Map(),
      monthlyRevolvingBalances: new Map(),
      perCardMinPayments: new Map(),
      monthlyCyclingOwed: new Map(),
      monthlyCyclingInterest: new Map(),
      projectedPayoffMonths: 0,
      cashFloorBreaches: [],
      flags: [],
      projectedCashByMonth: [],
      debtPaymentTransactions: [],
      warningMessages: [],
    };
  }

  // ── Step 1 — Initialise ────────────────────────────────────
  const balances = new Map<string, number>(cards.map(c => [c.id, c.balance]));
  const monthlyPayments = new Map<string, number[]>(cards.map(c => [c.id, []]));
  const monthlyBalances = new Map<string, number[]>(cards.map(c => [c.id, []]));
  const monthlyRevolvingBalances = new Map<string, number[]>(cards.map(c => [c.id, []]));
  const perCardMinPayments = new Map<string, number[]>(cards.map(c => [c.id, []]));
  const monthlyCyclingOwed = new Map<string, number[]>(cards.map(c => [c.id, []]));
  const monthlyCyclingInterest = new Map<string, number[]>(cards.map(c => [c.id, []]));
  let currentCash = liquidCash;
  let projectedPayoffMonths = 0;
  const cashFloorBreaches: { month: number; endingCash: number }[] = [];
  const flags: SimulationFlag[] = [];
  const projectedCashByMonth: number[] = [];
  const debtPaymentTransactions: SimulatedDebtPayment[] = [];
  const warningMessages: { month: number; message: string }[] = [];

  const now = new Date();

  // Month index (0 = current month) at which each card becomes active.
  // Cards with a future startDate are excluded from the simulation until their start month.
  const cardStartMonths = new Map<string, number>(cards.map(c => {
    if (!c.startDate) return [c.id, 0];
    const startD = new Date(c.startDate + 'T00:00:00');
    const diff = (startD.getFullYear() - now.getFullYear()) * 12 + (startD.getMonth() - now.getMonth());
    return [c.id, Math.max(0, diff)];
  }));

  // Tracks cards that have reached $0 — one-way transition, never re-enters debt mode.
  const paidOffCards = new Set<string>();

  // Grace period tracking for statement-balance preference cards.
  // When a card pays its full statement balance (startBal + interest), the new purchases
  // added that cycle are in grace period — no interest charged next billing cycle.
  const graceMap = new Map<string, boolean>(
    cards.map(c => [c.id, c.paymentPreference === 'statement' && (c.statementBalancePhase || c.balance <= c.monthlyNewPurchases + 0.01)]),
  );

  // Billing cycle deferred purchases: a paid-off card's charges in month m are paid
  // in month m+1 (statement closes at month-end, payment due ~25 days into next month).
  // Tracks PRINCIPAL only — any interest from a missed full payment is tracked separately
  // in pendingInterestCarry so it can be reported per-month instead of silently folded in.
  const paidOffDeferredPurchases = new Map<string, number>(cards.map(c => [c.id, 0]));
  // Interest owed next cycle because this cycle's payment didn't cover the full statement —
  // mirrors real card terms: missing a full statement payment loses the grace period and
  // accrues interest on the unpaid balance until it's caught up.
  const pendingInterestCarry = new Map<string, number>(cards.map(c => [c.id, 0]));

  for (let m = 0; m < months; m++) {

    // ── Income / expenses for this month ───────────────────────
    // Month 0: use caller-provided remaining-income/expenses (today → EOM).
    // Months 1+: fall back to monthEvents or scalar.
    const monthIncome = (m === 0 && month0RemainingIncome !== undefined)
      ? month0RemainingIncome
      : (monthEvents?.[m]?.income ?? monthlyTakeHome);
    const monthExpenses = (m === 0 && month0RemainingExpenses !== undefined)
      ? month0RemainingExpenses
      : (monthEvents?.[m]?.expenses ?? monthlyExpenses);

    // End-of-month ISO date for SimulatedDebtPayment records
    const payDate = new Date(now.getFullYear(), now.getMonth() + m + 1, 0);
    const payDateStr = payDate.toISOString().split('T')[0];

    // Per-card CC purchases this month.
    // Month 0 = 0: live card.balance already includes today's purchases.
    // Returns 0 for cards that haven't reached their start month yet.
    const cardPurchasesThisMonth = (c: CardData): number => {
      if ((cardStartMonths.get(c.id) ?? 0) > m) return 0;
      return cardPurchasesPerMonth?.[m]?.[c.id] ?? (m === 0 ? 0 : c.monthlyNewPurchases);
    };

    // Floor and one-time items — computed once per month, shared by Steps 2 and 5.
    const effectiveFloor = (m === 0 && month0SafeFloor !== undefined)
      ? month0SafeFloor
      : (cashFloorByMonth?.[m] ?? cashFloor);
    const oneTimeNet = m === 0 ? 0
      : (oneTimeByMonth?.[m]?.income ?? 0) - (oneTimeByMonth?.[m]?.expenses ?? 0);

    // Push 0 for cards that haven't reached their start month — keeps arrays aligned.
    // Also collect balance-sensitive minimum for each card this month (Option A).
    for (const card of cards) {
      if ((cardStartMonths.get(card.id) ?? 0) > m) {
        monthlyPayments.get(card.id)!.push(0);
        monthlyBalances.get(card.id)!.push(0);
        monthlyRevolvingBalances.get(card.id)!.push(0);
        perCardMinPayments.get(card.id)!.push(0);
        monthlyCyclingOwed.get(card.id)!.push(0);
        monthlyCyclingInterest.get(card.id)!.push(0);
      } else if (paidOffCards.has(card.id)) {
        perCardMinPayments.get(card.id)!.push(0);
      } else {
        const bal = balances.get(card.id) ?? 0;
        perCardMinPayments.get(card.id)!.push(bal > 0 ? Math.min(card.minPayment, bal) : 0);
      }
    }

    // ── Step 1 — Mark newly paid-off cards (one-way transition) ──
    for (const card of cards) {
      if ((cardStartMonths.get(card.id) ?? 0) > m) continue; // not active yet
      if (!paidOffCards.has(card.id) && (balances.get(card.id) ?? 0) <= 0) {
        paidOffCards.add(card.id);
      }
    }

    // ── Step 2 — Handle paid-off cards: pay purchases, capped by cash above floor ──
    // These cards stay at $0 permanently. Purchase cost is a cash outflow
    // but does NOT create a balance that accrues interest (grace period model).
    // Payments are deferred by one billing cycle: charges from month m are paid
    // in month m+1 (statement closes month-end, payment due ~25 days later).
    // Cap total paid-off payments so currentCash never drops below effectiveFloor.
    const tentativeAvailAboveFloor = Math.max(0, currentCash + monthIncome - monthExpenses + Math.max(0, oneTimeNet) - effectiveFloor);
    // Reserve revolving-card minimums before giving cash to autopay cards.
    // Without this, large deferred purchases (e.g. Venture X) drain the pool
    // entirely, leaving revolving cards (Prime, Discover) with nothing beyond
    // the minimum — causing balances to grow instead of paying down.
    const reservedForRevolving = cards
      .filter(c => !paidOffCards.has(c.id) && (cardStartMonths.get(c.id) ?? 0) <= m && (balances.get(c.id) ?? 0) > 0)
      .reduce((s, c) => s + c.minPayment, 0);
    let paidOffPool = Math.max(0, tentativeAvailAboveFloor - reservedForRevolving);
    let paidOffCashCost = 0;
    // Pay cycling cards in strategy order so highest-APR (avalanche) or lowest-balance
    // (snowball) card claims from the pool first when it runs short.
    const paidOffOrder = [...cards]
      .filter(c => paidOffCards.has(c.id))
      .sort((a, b) =>
        strategy === 'avalanche'
          ? b.apr - a.apr
          : (paidOffDeferredPurchases.get(a.id) ?? 0) - (paidOffDeferredPurchases.get(b.id) ?? 0)
      );
    for (const card of paidOffOrder) {
      // Pay PREVIOUS month's deferred charges (billing cycle delay), plus any interest
      // carried over from a prior cycle that wasn't paid in full.
      const principalOwed = paidOffDeferredPurchases.get(card.id) ?? 0;
      const interestDue = pendingInterestCarry.get(card.id) ?? 0;
      const owedThisCycle = Math.round((principalOwed + interestDue) * 100) / 100;
      monthlyCyclingOwed.get(card.id)!.push(owedThisCycle);
      monthlyCyclingInterest.get(card.id)!.push(interestDue);
      const pay = Math.round(Math.min(owedThisCycle, paidOffPool) * 100) / 100;
      paidOffPool -= pay;
      monthlyPayments.get(card.id)!.push(pay);
      paidOffCashCost += pay;
      if (pay > 0) {
        debtPaymentTransactions.push({
          date: payDateStr, description: `${card.name} Payment`,
          amount: pay, account: fundingAccountId ?? '',
          category: 'Debt Payments', card: card.id,
          type: 'debt_payoff', projected: true,
        });
      }
      // Carry forward any unpaid amount when the pool couldn't cover the full statement.
      // Without this, constrained months silently drop the deficit, causing the next
      // month to under-charge and the pay-off-pool to never catch up.
      const unpaidPrincipal = Math.round((owedThisCycle - pay) * 100) / 100;
      // Missing a full statement payment loses the grace period — the unpaid balance accrues
      // interest at the card's APR until it's caught up, same as a real card statement would.
      const interestForNextCycle = unpaidPrincipal > 0.01
        ? Math.round(unpaidPrincipal * (card.apr / 100 / 12) * 100) / 100
        : 0;
      pendingInterestCarry.set(card.id, interestForNextCycle);
      const thisMonthPurchases = Math.max(cardPurchasesThisMonth(card), card.monthlyNewPurchases);
      paidOffDeferredPurchases.set(card.id, unpaidPrincipal + thisMonthPurchases);
    }
    // Cards in paidOffOrder already pushed above — push 0 for cards not yet in cycling mode
    // this month (still revolving, or not yet active) to keep all per-month arrays aligned.
    for (const card of cards) {
      if ((cardStartMonths.get(card.id) ?? 0) > m || paidOffCards.has(card.id)) continue;
      monthlyCyclingOwed.get(card.id)!.push(0);
      monthlyCyclingInterest.get(card.id)!.push(0);
    }

    // Cards still carrying debt (exclude pre-start cards — they already got 0 pushed above)
    const debtCards = cards.filter(c => !paidOffCards.has(c.id) && (cardStartMonths.get(c.id) ?? 0) <= m);

    // All cards paid off — just advance cash and continue
    if (debtCards.length === 0) {
      for (const card of cards) {
        if ((cardStartMonths.get(card.id) ?? 0) <= m) {
          monthlyBalances.get(card.id)!.push(0);
          monthlyRevolvingBalances.get(card.id)!.push(0);
        }
      }
      currentCash += monthIncome - monthExpenses - paidOffCashCost;
      const oneTime = oneTimeByMonth?.[m];
      if (oneTime && (oneTime.income > 0 || oneTime.expenses > 0)) {
        currentCash += oneTime.income - oneTime.expenses;
      }
      projectedCashByMonth.push(Math.round(currentCash * 100) / 100);
      continue;
    }

    // ── Step 3 — Compute interest on STARTING balances ────────
    // Interest is charged only on the balance carried from last month.
    // For statement-balance preference cards in grace period (last payment covered
    // the full statement balance), new purchases carry without accruing interest —
    // matching real credit card grace period behavior.
    const interestMap = new Map<string, number>();
    for (const card of debtCards) {
      const bal = balances.get(card.id) ?? 0;
      const inGrace = card.paymentPreference === 'statement' && (graceMap.get(card.id) ?? false);
      const interest = inGrace ? 0 : Math.round(Math.max(0, bal) * (card.apr / 100 / 12) * 100) / 100;
      interestMap.set(card.id, interest);
    }

    // ── Step 4 — Balance before payment = startBal + interest + purchases ──
    const balBeforePayment = new Map<string, number>();
    for (const card of debtCards) {
      const bal = balances.get(card.id) ?? 0;
      const interest = interestMap.get(card.id) ?? 0;
      const purchases = cardPurchasesThisMonth(card);
      balBeforePayment.set(card.id, bal + interest + purchases);
    }

    // ── Step 5 — Available surplus for debt payoff ────────────
    const totalMins = debtCards.reduce((s, c) => {
      const bbp = balBeforePayment.get(c.id) ?? 0;
      return s + Math.min(c.minPayment, bbp);
    }, 0);

    // availableCash = what's left above the floor after income, expenses, paid-off costs,
    // and one-time items for this month.
    // Month 0 uses month0SafeFloor (= max(cashFloor, ppBills)) so the projection matches recommendations.
    // effectiveFloor and oneTimeNet are computed at top of this iteration (before Step 2).
    let availableCash = currentCash + monthIncome - monthExpenses - effectiveFloor - paidOffCashCost + oneTimeNet;
    if (availableCash < 0) {
      flags.push({ month: m + 1, flag: 'UNSTABLE' });
      availableCash = 0;
    }

    // Cap debt allocation in save-up months (look-ahead pre-pass set these to ccMinTotal)
    const mDebtCap = maxDebtPaymentByMonth?.[m];
    if (mDebtCap !== undefined && isFinite(mDebtCap) && availableCash > mDebtCap) {
      availableCash = mDebtCap;
    }

    const payments = new Map<string, number>(cards.map(c => [c.id, 0]));

    if (availableCash < totalMins) {
      // FLOOR_BREACHED: can't cover all minimums above the floor
      flags.push({ month: m + 1, flag: 'FLOOR_BREACHED' });
      cashFloorBreaches.push({ month: m + 1, endingCash: currentCash - totalMins - paidOffCashCost });

      // Snowball protection: pay smallest balances first when cash is tight
      const sortedForBreached = [...debtCards].sort(
        (a, b) => (balances.get(a.id) ?? 0) - (balances.get(b.id) ?? 0),
      );
      let remainingForMins = Math.max(0, currentCash);
      let atRiskWarningEmitted = false;
      for (const card of sortedForBreached) {
        const bbp = balBeforePayment.get(card.id) ?? 0;
        const min = Math.min(card.minPayment, bbp);
        if (remainingForMins >= min) {
          payments.set(card.id, min);
          remainingForMins -= min;
        } else {
          payments.set(card.id, 0);
          flags.push({ month: m + 1, flag: 'CARD_AT_RISK', cardId: card.id });
          if (!atRiskWarningEmitted) {
            warningMessages.push({
              month: m + 1,
              message: 'Available cash cannot cover all minimum payments. Consider reducing expenses or increasing income.',
            });
            atRiskWarningEmitted = true;
          }
        }
      }

    } else {
      // Sort by strategy only. Cards with a paymentPreference still have a revolving balance
      // here — they compete under normal avalanche/snowball until balance reaches zero, at
      // which point they transition to paidOffCards (cycling mode). No priority boost.
      const strategyOrder = [...debtCards].sort((a, b) =>
        strategy === 'avalanche'
          ? b.apr - a.apr
          : (balBeforePayment.get(a.id) ?? 0) - (balBeforePayment.get(b.id) ?? 0)
      );

      // ── Step 5a — Pay minimums ─────────────────────────────
      let remaining = availableCash;
      for (const card of strategyOrder) {
        const bbp = balBeforePayment.get(card.id) ?? 0;
        const min = Math.min(card.minPayment, bbp, remaining);
        payments.set(card.id, min);
        remaining -= min;
      }

      // ── Step 5b — Cascade surplus to priority cards ────────
      // Strategy order (avalanche/snowball) determines priority.
      // paymentPreference is an overlay that caps the amount allocated per card:
      //   null/full: pay as much as possible toward this card (standard cascade)
      //   statement: cap at startBal + interest — avoids paying new purchases this cycle
      for (const card of strategyOrder) {
        if (remaining <= 0) break;
        const bbp = balBeforePayment.get(card.id) ?? 0;
        const startBal = balances.get(card.id) ?? 0;
        const interest = interestMap.get(card.id) ?? 0;
        const currentPayment = payments.get(card.id) ?? 0;
        const target = card.paymentPreference === 'statement'
          ? Math.max(0, startBal + interest)
          : bbp;
        const maxExtra = Math.max(0, target - currentPayment);
        const extra = Math.min(remaining, maxExtra);
        if (extra > 0) {
          payments.set(card.id, currentPayment + extra);
          remaining -= extra;
        }
      }
    }

    // ── Minimum enforcement guard ──────────────────────────────────────
    // After all allocation, ensure every active debt card receives at least
    // Math.min(minPayment, balanceBeforePayment). Prevents rounding or edge-case
    // paths from silently skipping a minimum payment.
    for (const card of debtCards) {
      const bbp = balBeforePayment.get(card.id) ?? 0;
      const currentPay = payments.get(card.id) ?? 0;
      const minRequired = Math.min(card.minPayment, bbp);
      if (currentPay < minRequired && bbp > 0) {
        payments.set(card.id, minRequired);
      }
    }

    // ── Step 6 — Apply payments, update balances, emit transactions ──
    let totalDebtPayments = paidOffCashCost;
    for (const card of debtCards) {
      const startBal = balances.get(card.id) ?? 0;
      const interest = interestMap.get(card.id) ?? 0;
      const purchases = cardPurchasesThisMonth(card);
      const pay = Math.round((payments.get(card.id) ?? 0) * 100) / 100;
      monthlyPayments.get(card.id)!.push(pay);
      totalDebtPayments += pay;

      const bbp = balBeforePayment.get(card.id) ?? 0; // startBal + interest + purchases
      const endBal = Math.max(0, bbp - pay);
      const finalBal = endBal < 1 ? 0 : endBal; // clear sub-dollar dust
      balances.set(card.id, finalBal);
      // When the revolving balance just reached $0, pre-seed deferred purchases so the
      // first paidOff month pays monthlyNewPurchases instead of $0 (billing-delay artifact).
      // Fall back to monthlyNewPurchases for statement/autopay cards whose rules aren't tagged
      // with this card's payment_source (cardPurchasesThisMonth would be 0 → $0/$— display).
      if (finalBal === 0 && !paidOffCards.has(card.id)) {
        const seedAmt = (card.paymentPreference === 'statement' || card.autopayFullBalance)
          ? Math.max(cardPurchasesThisMonth(card), card.monthlyNewPurchases)
          : cardPurchasesThisMonth(card);
        paidOffDeferredPurchases.set(card.id, seedAmt);
      }

      // Statement-preference cards never hit finalBal === 0 while carrying revolving debt
      // (end balance = purchases > 0). Transition them to paidOffCards when the remaining
      // balance equals only the recurring purchases — i.e., revolving debt is gone.
      if (
        card.paymentPreference === 'statement' &&
        !paidOffCards.has(card.id) &&
        finalBal > 0 &&
        finalBal <= cardPurchasesThisMonth(card) + 0.01
      ) {
        paidOffCards.add(card.id);
        paidOffDeferredPurchases.set(card.id,
          Math.max(cardPurchasesThisMonth(card), card.monthlyNewPurchases));
        balances.set(card.id, 0);
      }

      // Update grace state: grace applies next month if this month's payment covered
      // the full statement balance (startBal + interest), i.e., nothing carried over.
      if (card.paymentPreference === 'statement') {
        graceMap.set(card.id, pay >= startBal + interest - 0.01);
      }

      if (pay > 0) {
        debtPaymentTransactions.push({
          date: payDateStr, description: `${card.name} Payment`,
          amount: pay, account: fundingAccountId ?? '',
          category: 'Debt Payments', card: card.id,
          type: 'debt_payoff', projected: true,
        });
      }
    }

    // Record end-of-month balance for all active cards (paid-off cards have balances = 0)
    for (const card of cards) {
      if ((cardStartMonths.get(card.id) ?? 0) <= m) {
        const endBal = balances.get(card.id) ?? 0;
        monthlyBalances.get(card.id)!.push(endBal);
        // For statement-preference cards, subtract actual purchases charged this month so only
        // the revolving carry-over (interest-bearing debt) is counted. Month 0 uses 0 purchases
        // (live balance already includes them), so endBal itself is the revolving balance.
        const revolvingBal = card.paymentPreference === 'statement'
          ? Math.max(0, endBal - cardPurchasesThisMonth(card))
          : endBal;
        monthlyRevolvingBalances.get(card.id)!.push(revolvingBal);
      }
    }

    // Payoff ETA = last month where any card still carried debt
    projectedPayoffMonths = m + 1;

    // ── Step 7 — Advance cash ──────────────────────────────────
    currentCash += monthIncome - monthExpenses - totalDebtPayments;
    // One-time items applied AFTER debt allocation to avoid look-ahead cash hoarding
    const oneTime = oneTimeByMonth?.[m];
    if (oneTime && (oneTime.income > 0 || oneTime.expenses > 0)) {
      currentCash += oneTime.income - oneTime.expenses;
    }
    projectedCashByMonth.push(Math.round(currentCash * 100) / 100);
  }

  return {
    monthlyPayments,
    monthlyBalances,
    monthlyRevolvingBalances,
    perCardMinPayments,
    monthlyCyclingOwed,
    monthlyCyclingInterest,
    projectedPayoffMonths,
    cashFloorBreaches,
    flags,
    projectedCashByMonth,
    debtPaymentTransactions,
    warningMessages,
  };
}

/**
 * Generate due-date-aware recommendations using estimated liquid cash by each card's due date.
 */
export function generateRecommendations(
  cards: CardData[],
  liquidCash: number,
  cashFloor: number,
  strategy: 'avalanche' | 'snowball',
  monthlyTakeHome: number,
  monthlyExpenses: number,
  paymentMode: 'variable' | 'consistent' = 'variable',
  payConfig?: PayScheduleConfig,
  rules?: any[],
  fundingAccountId?: string | null,
  prePaycheckBillsTotal?: number,
  fundingBalance?: number,
  oneTimeExpensesThisMonth?: number,
  oneTimeIncomeThisMonth?: number,
  transactions?: any[],
  primaryDueDay?: number,
  monthlySavingsAndCar?: number,
  syncCutoffDate?: string,
): RecommendationSummary {
  // Preference cards = zero-balance cycling cards only (balance <= 0 encoded in autopayFullBalance).
  // Positive-balance full/statement cards compete under normal strategy in revolvingCards —
  // the preference only kicks in once the balance reaches zero (cycling mode going forward).
  const preferenceCards = cards.filter(c => c.autopayFullBalance);
  const revolvingCards = cards.filter(c => !c.autopayFullBalance && c.balance > 0);

  const totalMinDue = revolvingCards.reduce((s, c) => s + c.minPayment, 0);

  const userCashFloor = cashFloor;
  const ppBills = prePaycheckBillsTotal ?? 0;
  const recommendedSafeMinimum = Math.max(userCashFloor, ppBills);

  const effectiveFundingBalance = fundingBalance ?? liquidCash;

  const effectivePrimaryDueDay = primaryDueDay ?? (() => {
    const revolving = cards.filter(c => !c.autopayFullBalance && c.balance > 0);
    if (revolving.length === 0) return 31;
    const dueDays = revolving.map(c => c.dueDay || 31);
    return Math.min(...dueDays);
  })();

  let remainingTransactionIncome = 0;
  let remainingTransactionExpenses = 0;

  if (transactions && transactions.length > 0) {
    const fundingSources = fundingAccountId
      ? new Set([fundingAccountId, `account:${fundingAccountId}`])
      : new Set<string>();
    remainingTransactionIncome = getRemainingTransactionIncomeByDay(transactions, 31, syncCutoffDate);
    remainingTransactionExpenses = getRemainingTransactionExpensesByDay(
      transactions, 31, true, fundingSources, CC_DEFAULT_CATEGORIES, syncCutoffDate,
    );
  } else if (payConfig && rules) {
    remainingTransactionIncome = getRemainingIncomeByDay(payConfig, 31)
      + getRemainingNonPaycheckIncomeByDay(rules, 31, fundingAccountId || null);
    remainingTransactionExpenses = getRemainingExpensesByDay(rules, 31, fundingAccountId || null);
  } else {
    remainingTransactionIncome = monthlyTakeHome;
    remainingTransactionExpenses = monthlyExpenses;
  }

  const remainingPaycheckIncome = remainingTransactionIncome;
  const remainingNonPaycheckIncome = 0;
  const remainingOneTimeIncome = 0;
  const remainingExpenses = remainingTransactionExpenses;
  const remainingOneTimeExpenses = 0;

  const totalRemainingIncome = remainingTransactionIncome;
  const totalRemainingOutflows = remainingTransactionExpenses;

  // Preference cards (statement/full) are allocated first, capped by cash above floor.
  // Subtract outflows (bank bills through due date) so upcoming expenses aren't ignored.
  const availableAboveFloor = Math.max(0,
    effectiveFundingBalance + totalRemainingIncome - totalRemainingOutflows - recommendedSafeMinimum
  );
  let preferencePool = availableAboveFloor;
  let autopayTotal = 0;
  const preferenceRecs: PayoffRecommendation[] = [];

  for (const card of preferenceCards) {
    const desired = card.paymentPreference === 'full'
      ? Math.max(0, card.balance) + card.monthlyNewPurchases
      : card.monthlyNewPurchases;
    const actual = Math.round(Math.min(desired, preferencePool) * 100) / 100;
    preferencePool -= actual;
    autopayTotal += actual;
    preferenceRecs.push({
      cardId: card.id, cardName: card.name, color: card.color,
      payment: actual,
      isMinimumOnly: actual < desired,
      reason: card.paymentPreference === 'full' ? 'Pay Full Balance'
        : card.paymentPreference === 'statement' ? 'Pay Statement Balance'
        : 'Pay Monthly Charges',
      dueDay: card.dueDay,
    });
  }

  const safeToPayTotal = preferencePool; // remaining for revolving cards

  const cashWarning = Math.ceil(safeToPayTotal - totalMinDue) < 0;

  const cardEstimatedCash = new Map<string, number>();
  for (const card of revolvingCards) {
    const dueDay = card.dueDay || 31;
    if (transactions && transactions.length > 0) {
      const incByDue = getRemainingTransactionIncomeByDay(transactions, dueDay, syncCutoffDate);
      cardEstimatedCash.set(card.id, effectiveFundingBalance + incByDue);
    } else {
      cardEstimatedCash.set(card.id, effectiveFundingBalance + totalRemainingIncome);
    }
  }

  const strategyLabels: Record<string, string> = {
    avalanche: 'Highest APR First',
    snowball: 'Smallest Balance First',
  };

  let remaining = safeToPayTotal;
  const recs: PayoffRecommendation[] = [...preferenceRecs];

  // Pure strategy sort — no preference-card priority. Full/statement positive-balance
  // cards compete under normal avalanche/snowball until their balance reaches zero.
  const sorted = [...revolvingCards].sort((a, b) =>
    strategy === 'avalanche' ? b.apr - a.apr : a.balance - b.balance
  );

  for (const card of sorted) {
    const basePayment = Math.max(0, Math.min(card.minPayment, remaining, card.balance));
    recs.push({
      cardId: card.id, cardName: card.name, color: card.color, payment: basePayment,
      isMinimumOnly: true,
      reason: 'Minimum due',
      estimatedLiquidCash: cardEstimatedCash.get(card.id),
      dueDay: card.dueDay,
    });
    remaining -= basePayment;
  }

  if (remaining > 0) {
    for (let i = 0; i < sorted.length && remaining > 0; i++) {
      const card = sorted[i];
      const rec = recs.find(r => r.cardId === card.id)!;
      // statement preference: cap extra at current balance (don't pre-pay new purchases)
      // full or null: pay balance + anticipated new purchases (clear the card fully)
      const maxExtra = card.paymentPreference === 'statement'
        ? Math.max(0, card.balance - rec.payment)
        : Math.max(0, card.balance + card.monthlyNewPurchases - rec.payment);
      const extra = Math.min(remaining, maxExtra);
      if (extra > 0) {
        rec.payment += extra;
        rec.isMinimumOnly = false;
        // Show the preference label only when the payment actually clears the desired amount.
        // While the card still carries revolving debt the strategy label is more accurate.
        const payingFull = card.paymentPreference === 'full'
          && rec.payment >= card.balance + card.monthlyNewPurchases - 0.01;
        const payingStatement = card.paymentPreference === 'statement'
          && rec.payment >= card.balance - 0.01;
        rec.reason = payingFull ? 'Pay Full Balance'
          : payingStatement ? 'Pay Statement Balance'
          : strategy === 'avalanche'
          ? `Highest APR (${card.apr}%)`
          : `Smallest balance (${formatCurrency(card.balance, false)})`;
        remaining -= extra;
      }
    }
  }

  const interestMinOnly = revolvingCards.reduce((s, c) => s + (c.balance * (c.apr / 100 / 12)), 0);
  const interestWithRecs = revolvingCards.reduce((s, c) => {
    const rec = recs.find(r => r.cardId === c.id);
    const afterPayment = Math.max(0, c.balance - (rec?.payment || 0) + c.monthlyNewPurchases);
    return s + afterPayment * (c.apr / 100 / 12);
  }, 0);

  const { projectedPayoffMonths } = simulateVariablePayoff(
    cards, liquidCash, cashFloor, strategy, monthlyTakeHome, monthlyExpenses, 120,
  );

  const totalLimit = cards.reduce((s, c) => s + c.creditLimit, 0);
  const thresholds = [30, 10];
  const milestones = thresholds.map(t => {
    let simB = cards.map(c => c.autopayFullBalance ? 0 : c.balance);
    for (let m = 0; m < 120; m++) {
      const totalBal = simB.reduce((s, b) => s + Math.max(0, b), 0);
      const util = totalLimit > 0 ? (totalBal / totalLimit) * 100 : 0;
      if (util <= t) return { threshold: t, month: m };
      simB = simB.map((bal, i) => {
        if (bal <= 0 || cards[i].autopayFullBalance) return 0;
        const card = cards[i];
        const effectiveBal = bal < 1 ? 0 : bal;
        if (effectiveBal === 0) return Math.max(0, card.monthlyNewPurchases);
        const rec = recs.find(r => r.cardId === card.id);
        return Math.max(0, effectiveBal + card.monthlyNewPurchases
          + effectiveBal * (card.apr / 100 / 12) - (rec?.payment || card.minPayment));
      });
    }
    return { threshold: t, month: null };
  });

  const filteredRecs = recs.filter(r => r.payment > 0);
  const totalRecommendedPayment = filteredRecs.reduce((s, r) => s + r.payment, 0);

  return {
    totalAvailableCash: totalRecommendedPayment,
    totalMinimumsdue: totalMinDue,
    extraCashAvailable: Math.max(0, safeToPayTotal - totalMinDue),
    recommendations: filteredRecs,
    interestAvoided: Math.round((interestMinOnly - interestWithRecs) * 100) / 100,
    projectedPayoffMonths,
    utilizationMilestones: milestones,
    cashWarning,
    strategyLabel: strategyLabels[strategy] || strategy,
    recommendedSafeMinimum,
    userCashFloor,
    prePaycheckBills: ppBills,
    breakdown: {
      fundingBalance: effectiveFundingBalance,
      remainingPaycheckIncome,
      remainingNonPaycheckIncome,
      remainingOneTimeIncome,
      remainingExpenses,
      remainingOneTimeExpenses,
      safeMinimum: recommendedSafeMinimum,
      autopayTotal,
    },
  };
}

/**
 * Shared helper: compute current-month debt payment recommendations.
 * Used by Dashboard, Budget Control, Savings Goals, and Forecast to get
 * the same debt payment values that Debt Payoff displays.
 */
export type MonthlyDebtBreakdown = {
  recommendations: { cardId: string; cardName: string; color: string; payment: number; dueDay: number | null; reason: string; isMinimumOnly: boolean }[];
  totalMinimumsDue: number;
  totalRecommended: number;
  totalAvailableCash: number;
  autopayTotal: number;
  strategyLabel: string;
  cashWarning: boolean;
  interestAvoided: number;
};

function buildCurrentMonthRecommendationSummary(
  accounts: any[],
  transactions: any[],
  rules: any[],
  debts: any[],
  profile: any,
  monthlySavingsAndCar?: number,
  safeMinimumOverride?: number,
  syncCutoffDate?: string,
  extraMonthlyExpenses = 0,
): RecommendationSummary | null {
  if (!accounts || !transactions || !rules || !debts) return null;
  const cards = buildCardData(accounts, transactions, rules, debts);
  if (cards.length === 0) return null;

  const liquidTypes = ['checking', 'business_checking', 'cash'];
  const liquidAccounts = accounts.filter((a: any) => a.active && liquidTypes.includes(a.account_type));
  const liquidCash = liquidAccounts.reduce((s: number, a: any) => s + Number(a.balance), 0);
  const cashFloor = profile?.cash_floor != null ? Number(profile.cash_floor) : 1000;
  const pc = buildPayConfig(profile);
  const monthlyTakeHome = getMonthNetIncome(pc, new Date().getFullYear(), new Date().getMonth());
  const now0 = new Date();
  const monthlyExpenses = rules.filter((r: any) => {
    if (!r.active) return false;
    if (r.rule_type === 'transfer' || r.rule_type === 'investment') {
      if (r.start_date && new Date(r.start_date + 'T00:00:00') > now0) return false;
      if (r.end_date && new Date(r.end_date + 'T00:00:00') < now0) return false;
      return true;
    }
    if (r.rule_type !== 'expense') return false;
    return true;
  }).reduce((s: number, r: any) => {
    const amt = Number(r.amount);
    return s + amt * countRuleOccurrencesInMonth(r, now0.getFullYear(), now0.getMonth(), now0);
  }, 0);

  const defaultId = profile?.default_deposit_account || null;
  let fundingAccountId: string | null = null;
  if (defaultId) {
    const acct = liquidAccounts.find((a: any) => a.id === defaultId);
    if (acct) fundingAccountId = acct.id;
  }
  if (!fundingAccountId) {
    const checking = liquidAccounts.find((a: any) => a.account_type === 'checking');
    fundingAccountId = checking?.id || liquidAccounts[0]?.id || null;
  }

  const fundAcct = liquidAccounts.find((a: any) => a.id === fundingAccountId);
  const fundBal = fundAcct ? Number(fundAcct.balance) : liquidCash;
  const { total: ppBills } = getPrePaycheckNextMonthBills(rules, pc, fundingAccountId);

  const revolving = cards.filter(c => !c.autopayFullBalance && c.balance > 0);
  const primaryDueDay = revolving.length > 0
    ? Math.min(...revolving.map(c => c.dueDay || 31))
    : 31;

  return generateRecommendations(
    cards, liquidCash, cashFloor, 'avalanche', monthlyTakeHome, monthlyExpenses + extraMonthlyExpenses,
    'variable', pc, rules, fundingAccountId, safeMinimumOverride ?? ppBills, fundBal,
    undefined, undefined, transactions, primaryDueDay, monthlySavingsAndCar,
    syncCutoffDate,
  );
}

export function getMonthlyDebtBreakdown(
  accounts: any[],
  transactions: any[],
  rules: any[],
  debts: any[],
  profile: any,
  monthlySavingsAndCar?: number,
  safeMinimumOverride?: number,
  syncCutoffDate?: string,
  extraMonthlyExpenses = 0,
): MonthlyDebtBreakdown {
  const summary = buildCurrentMonthRecommendationSummary(accounts, transactions, rules, debts, profile, monthlySavingsAndCar, safeMinimumOverride, syncCutoffDate, extraMonthlyExpenses);
  if (!summary) return { recommendations: [], totalMinimumsDue: 0, totalRecommended: 0, totalAvailableCash: 0, autopayTotal: 0, strategyLabel: 'Avalanche', cashWarning: false, interestAvoided: 0 };
  return {
    recommendations: summary.recommendations.map(r => ({
      cardId: r.cardId,
      cardName: r.cardName,
      color: r.color,
      payment: r.payment,
      dueDay: r.dueDay || null,
      reason: r.reason,
      isMinimumOnly: r.isMinimumOnly,
    })),
    totalMinimumsDue: summary.totalMinimumsdue,
    totalRecommended: summary.recommendations.reduce((s, r) => s + r.payment, 0),
    totalAvailableCash: summary.totalAvailableCash,
    autopayTotal: summary.breakdown.autopayTotal,
    strategyLabel: summary.strategyLabel,
    cashWarning: summary.cashWarning,
    interestAvoided: summary.interestAvoided,
  };
}

export function getCurrentMonthDebtRecommendations(
  accounts: any[],
  transactions: any[],
  rules: any[],
  debts: any[],
  profile: any,
  monthlySavingsAndCar?: number,
  extraMonthlyExpenses = 0,
): { cardId: string; cardName: string; payment: number; dueDay: number | null; reason: string }[] {
  const summary = buildCurrentMonthRecommendationSummary(accounts, transactions, rules, debts, profile, monthlySavingsAndCar, undefined, undefined, extraMonthlyExpenses);
  if (!summary) return [];
  return summary.recommendations.map(r => ({
    cardId: r.cardId,
    cardName: r.cardName,
    payment: r.payment,
    dueDay: r.dueDay || null,
    reason: r.reason,
  }));
}
