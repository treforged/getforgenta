import { useState, useMemo } from 'react';
import { usePersistedState } from '@/hooks/usePersistedState';
import { requestReviewAfterAction } from '@/hooks/useInAppReview';
import { Link } from 'react-router-dom';
import { PageSkeleton } from '@/components/shared/PageSkeleton';
import InstructionsModal from '@/components/shared/InstructionsModal';
import { formatCurrency, calculateMonthlyPayment } from '@/lib/calculations';
import { useSavingsGoals, useCarFunds, useAccounts, useRecurringRules, useProfile, useTransactions, useDebts } from '@/hooks/useSupabaseData';
import ProgressBar from '@/components/shared/ProgressBar';
import FormModal from '@/components/shared/FormModal';
import { useSubscription } from '@/hooks/useSubscription';
import { useDemo } from '@/contexts/DemoContext';
import { Plus, Edit2, Trash2, Car, Copy, Link2, Crown } from 'lucide-react';
import * as DebtEngine from '@/lib/credit-card-engine';
import { mergeWithGeneratedTransactions, createDebtPaymentTransactions, mergeDebtPaymentsIntoStream, getAccountRemainingCashThisMonth } from '@/lib/pay-schedule';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { toast } from 'sonner';

const CHART_COLORS = ['hsl(43, 56%, 52%)', 'hsl(142, 50%, 40%)', 'hsl(200, 60%, 50%)', 'hsl(280, 50%, 50%)'];
const GOAL_TYPES = ['Emergency Fund', 'Vacation', 'Down Payment', 'Car Fund', 'Retirement', 'Custom'];
const emptyForm = { name: '', target_amount: '', current_amount: '', monthly_contribution: '', target_date: '', goal_type: 'Custom', linked_account: '', contribution_start_date: '', linked_rule_id: '' };
const emptyCarForm = { name: '', target_amount: '', current_amount: '', monthly_contribution: '', target_date: '', goal_type: 'Car Fund', target_price: '', tax_fees: '', monthly_insurance: '', expected_apr: '', loan_term_months: '', linked_account: '', contribution_start_date: '', linked_rule_id: '' };

const toMonthly = (amount: number, freq: string) =>
  freq === 'weekly' ? amount * 52 / 12
  : freq === 'biweekly' ? amount * 26 / 12
  : freq === 'yearly' ? amount / 12
  : amount;

// getAccountScheduledOutflows removed — replaced by transaction-based getAccountRemainingCashThisMonth from pay-schedule

function SavingsGrowthChart({ goals }: { goals: any[] }) {
  const chartData = useMemo(() => {
    const today = new Date();
    const todayYear = today.getFullYear();
    const todayMonth = today.getMonth();
    const months: Record<string, any>[] = [];
    for (let i = 0; i < 12; i++) {
      const entry: Record<string, any> = { month: new Date(todayYear, todayMonth + i).toLocaleString('en', { month: 'short', year: '2-digit' }) };
      goals.forEach(g => {
        let monthsContributed = i;
        if (g.contribution_start_date) {
          const start = new Date(g.contribution_start_date + 'T00:00:00');
          const j = (start.getFullYear() - todayYear) * 12 + (start.getMonth() - todayMonth);
          if (j > 0) monthsContributed = Math.max(0, i - (j - 1));
        }
        entry[g.name] = Math.min(Number(g.current_amount) + Number(g.monthly_contribution) * monthsContributed, Number(g.target_amount));
      });
      months.push(entry);
    }
    return months;
  }, [goals]);

  if (goals.length === 0) return null;
  return (
    <div className="card-forged p-4 sm:p-5 overflow-hidden w-full">
      <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 sm:mb-5">Savings Growth Projection</h3>
      <ResponsiveContainer width="100%" height={window.innerWidth < 640 ? 200 : 260}>
        <LineChart data={chartData} margin={{ left: 0, right: 0, top: 5, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(0, 0%, 15%)" />
          <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'hsl(240, 4%, 46%)' }} axisLine={false} tickLine={false} interval={window.innerWidth < 640 ? Math.ceil(chartData.length / 5) : 0} />
          <YAxis tick={{ fontSize: 11, fill: 'hsl(240, 4%, 46%)' }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
          <Tooltip contentStyle={{ background: 'hsl(0, 0%, 8%)', border: '1px solid hsl(0, 0%, 15%)', borderRadius: 'var(--radius)', fontSize: 12 }} formatter={(value: number) => formatCurrency(value, false)} />
          <Legend wrapperStyle={{ fontSize: 11, paddingTop: 8 }} />
          {goals.map((g, i) => <Line key={g.id} dataKey={g.name} stroke={CHART_COLORS[i % CHART_COLORS.length]} strokeWidth={2.5} dot={{ r: 3 }} />)}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default function SavingsGoals() {
  const { data: goals, add, update, remove } = useSavingsGoals();
  const { data: carFunds, add: addCarFund, update: updateCarFund, remove: removeCarFund } = useCarFunds();
  const { data: accounts, loading: accountsLoading } = useAccounts();
  const { data: rules } = useRecurringRules();
  const { data: profile } = useProfile();
  const { data: txns } = useTransactions();
  const { data: debts } = useDebts();
  const { isPremium } = useSubscription();
  const { isDemo } = useDemo();
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const cashFloor = Number((profile as any)?.cash_floor) || 1000;
  const [pauseSavings] = usePersistedState<boolean>('tre:debtpayoff:pause-savings', false);

  const monthlySavingsAndCar = useMemo(() => {
    if (pauseSavings) return 0;
    const retireIds = new Set<string>(
      accounts.filter((a: any) => a.active && ['401k', 'roth_ira', 'ira', 'hsa'].includes(a.account_type)).map((a: any) => a.id),
    );
    const now = new Date();
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    const activeTransferDests = new Set<string>(
      (rules as any[]).filter((r: any) =>
        r.active && (r.rule_type === 'transfer' || r.rule_type === 'investment') && r.deposit_account &&
        !(r.start_date && new Date(r.start_date + 'T00:00:00') > monthEnd) &&
        !(r.end_date && new Date(r.end_date + 'T00:00:00') < now),
      ).map((r: any) => r.deposit_account),
    );
    const savingsTotal = (goals as any[] ?? []).reduce((s: number, g: any) => {
      if (g.contribution_start_date && new Date(g.contribution_start_date + 'T00:00:00') > now) return s;
      if (g.linked_account && retireIds.has(g.linked_account)) return s;
      if (g.linked_account && activeTransferDests.has(g.linked_account)) return s;
      return s + Number(g.monthly_contribution);
    }, 0);
    const carTotal = (carFunds as any[] ?? []).reduce((s: number, c: any) => {
      const rem = Number(c.down_payment_goal) - Number(c.current_saved);
      return s + (rem > 0 ? Math.min(rem / 12, 500) : 0);
    }, 0);
    return savingsTotal + carTotal;
  }, [pauseSavings, goals, carFunds, accounts, rules]);

  // Build full transaction stream including debt payments for linked-account math
  const baseTxns = useMemo(() => mergeWithGeneratedTransactions(txns || [], rules, accounts), [txns, rules, accounts]);
  const debtRecs = useMemo(() => {
  try {
    return DebtEngine.getCurrentMonthDebtRecommendations(
      accounts,
      baseTxns,
      rules,
      debts,
      profile,
      monthlySavingsAndCar
    );
  } catch (e) {
    console.error('Debt engine failed:', e);
    return [];
  }
}, [accounts, baseTxns, rules, debts, profile, monthlySavingsAndCar]);
  const debtTxns = useMemo(() => {
    const fundId = (profile as any)?.default_deposit_account ||
      accounts.find((a: any) => a.account_type === 'checking' && a.active)?.id || null;
    return createDebtPaymentTransactions(debtRecs, fundId);
  }, [debtRecs, profile, accounts]);
  const allTxns = useMemo(() => mergeDebtPaymentsIntoStream(baseTxns, debtTxns), [baseTxns, debtTxns]);

  // Account lookup
  const accountMap = useMemo(() => {
    const map: Record<string, any> = {};
    accounts.forEach((a: any) => { map[a.id] = a; });
    return map;
  }, [accounts]);

  // Merge car funds into goals for display
  const carGoals = useMemo(() => carFunds.map((c: any) => ({
    id: `car:${c.id}`,
    name: c.vehicle_name,
    target_amount: Number(c.down_payment_goal),
    current_amount: Number(c.current_saved),
    monthly_contribution: 0,
    target_date: null,
    goal_type: 'Car Fund',
    car_data: c,
    linked_account: (c as any).linked_account || null,
  })), [carFunds]);

  // Compute available-after-outflows for linked accounts using transaction-based math
  // Formula: account balance + remaining income - remaining expenses (including debt) - cash floor
  const getLinkedAmount = (accountId: string) => {
    const acct = accountMap[accountId];
    if (!acct) return 0;
    return getAccountRemainingCashThisMonth(accountId, acct.account_type, allTxns, Number(acct.balance), cashFloor);
  };

  const allGoals = useMemo(() => {
    const carNames = new Set(carGoals.map(c => c.name.toLowerCase()));
    const filtered = goals.filter(g => !carNames.has(g.name.toLowerCase()));
    return [...filtered.map(g => {
      const linkedRule = (g as any).linked_rule_id
        ? rules.find((r: any) => r.id === (g as any).linked_rule_id)
        : null;
      return {
        ...g,
        goal_type: (g as any).goal_type || 'Custom',
        current_amount: (g as any).linked_account && accountMap[(g as any).linked_account]
          ? Number(accountMap[(g as any).linked_account].balance)
          : Number(g.current_amount),
        available_after_outflows: (g as any).linked_account && accountMap[(g as any).linked_account]
          ? getLinkedAmount((g as any).linked_account)
          : null,
        monthly_contribution: linkedRule
          ? toMonthly(Number(linkedRule.amount), linkedRule.frequency)
          : Number(g.monthly_contribution),
        contribution_start_date: linkedRule?.start_date ?? (g as any).contribution_start_date ?? null,
        linked_rule: linkedRule || null,
      };
    }), ...carGoals];
  }, [goals, carGoals, accountMap, rules, cashFloor]);

  const totalSaved = allGoals.reduce((s, g) => s + Number(g.current_amount), 0);
  const totalTarget = allGoals.reduce((s, g) => s + Number(g.target_amount), 0);

  const accountOptions = useMemo(() => [
    { value: '', label: 'None (Manual)' },
    ...accounts.filter((a: any) => a.active).map((a: any) => ({ value: a.id, label: `${a.name} (${a.account_type.replace(/_/g, ' ')})` })),
  ], [accounts]);

  const transferRuleOptions = useMemo(() => [
    { value: '', label: 'None (manual)' },
    ...rules
      .filter((r: any) => (r.rule_type === 'transfer' || r.rule_type === 'investment') && r.active)
      .map((r: any) => ({ value: r.id, label: `${r.name} — ${formatCurrency(r.amount, false)}/${r.frequency}` })),
  ], [rules]);

  const openAdd = (goalType = 'Custom') => {
    if (goalType === 'Car Fund') setForm({ ...emptyCarForm });
    else setForm({ ...emptyForm, goal_type: goalType });
    setEditId(null); setShowForm(true);
  };

  const openEdit = (g: any) => {
    if (g.goal_type === 'Car Fund' && g.car_data) {
      const c = g.car_data;
      setForm({
        name: c.vehicle_name, target_amount: String(c.down_payment_goal), current_amount: String(c.current_saved),
        monthly_contribution: '0', target_date: '', goal_type: 'Car Fund',
        target_price: String(c.target_price), tax_fees: String(c.tax_fees),
        monthly_insurance: String(c.monthly_insurance), expected_apr: String(c.expected_apr),
        loan_term_months: String(c.loan_term_months), linked_account: '',
      } as any);
    } else {
      setForm({
        name: g.name, target_amount: String(g.target_amount), current_amount: String(g.current_amount),
        monthly_contribution: String(g.monthly_contribution), target_date: g.target_date || '',
        goal_type: g.goal_type || 'Custom', linked_account: (g as any).linked_account || '',
        contribution_start_date: (g as any).contribution_start_date || '',
        linked_rule_id: (g as any).linked_rule_id || '',
      });
    }
    setEditId(g.id); setShowForm(true);
  };

  const handleDuplicate = (g: any) => {
    if (g.goal_type === 'Car Fund' && g.car_data) {
      const c = g.car_data;
      setForm({
        name: `${c.vehicle_name} (Copy)`, target_amount: String(c.down_payment_goal), current_amount: '0',
        monthly_contribution: '0', target_date: '', goal_type: 'Car Fund',
        target_price: String(c.target_price), tax_fees: String(c.tax_fees),
        monthly_insurance: String(c.monthly_insurance), expected_apr: String(c.expected_apr),
        loan_term_months: String(c.loan_term_months), linked_account: '',
      } as any);
    } else {
      setForm({
        name: `${g.name} (Copy)`, target_amount: String(g.target_amount), current_amount: '0',
        monthly_contribution: String(g.monthly_contribution), target_date: g.target_date || '',
        goal_type: g.goal_type || 'Custom', linked_account: (g as any).linked_account || '',
        contribution_start_date: (g as any).contribution_start_date || '',
        linked_rule_id: (g as any).linked_rule_id || '',
      });
    }
    setEditId(null); setShowForm(true);
    toast.info('Goal duplicated — edit and save');
  };

  const handleSave = () => {
    const target_amount = parseFloat(form.target_amount);
    if (!form.name || isNaN(target_amount)) return;

    // Handle car fund updates
    if (editId && editId.startsWith('car:')) {
      const carId = editId.replace('car:', '');
      const carPayload: any = {
        id: carId,
        vehicle_name: form.name,
        down_payment_goal: target_amount,
        current_saved: parseFloat(form.current_amount) || 0,
      };
      const f = form as any;
      if (f.target_price !== undefined) carPayload.target_price = parseFloat(f.target_price) || 0;
      if (f.tax_fees !== undefined) carPayload.tax_fees = parseFloat(f.tax_fees) || 0;
      if (f.monthly_insurance !== undefined) carPayload.monthly_insurance = parseFloat(f.monthly_insurance) || 0;
      if (f.expected_apr !== undefined) carPayload.expected_apr = parseFloat(f.expected_apr) || 0;
      if (f.loan_term_months !== undefined) carPayload.loan_term_months = parseInt(f.loan_term_months) || 60;
      updateCarFund.mutate(carPayload);
      setShowForm(false);
      return;
    }

    const payload: any = {
      name: form.name, target_amount, current_amount: parseFloat(form.current_amount) || 0,
      monthly_contribution: parseFloat(form.monthly_contribution) || 0,
      target_date: form.target_date || null,
      linked_account: form.linked_account || null,
      goal_type: form.goal_type || 'Custom',
      contribution_start_date: (form as any).contribution_start_date || null,
      linked_rule_id: (form as any).linked_rule_id || null,
    };
    if (editId) {
      update.mutate({ id: editId, ...payload });
    } else {
      add.mutate(payload);
      requestReviewAfterAction();
    }
    setShowForm(false);
  };

  const handleDelete = (id: string) => {
    if (id.startsWith('car:')) {
      const carId = id.replace('car:', '');
      if (deleteConfirm === id) { removeCarFund.mutate(carId); setDeleteConfirm(null); }
      else { setDeleteConfirm(id); setTimeout(() => setDeleteConfirm(null), 3000); }
      return;
    }
    if (deleteConfirm === id) { remove.mutate(id); setDeleteConfirm(null); }
    else { setDeleteConfirm(id); setTimeout(() => setDeleteConfirm(null), 3000); }
  };

  function estimateCompletion(g: any): string {
    const remaining = Number(g.target_amount) - Number(g.current_amount);
    if (remaining <= 0) return 'Complete';
    if (Number(g.monthly_contribution) <= 0) return 'Set contribution';
    let delay = 0;
    if (g.contribution_start_date) {
      const today = new Date();
      const start = new Date(g.contribution_start_date + 'T00:00:00');
      const j = (start.getFullYear() - today.getFullYear()) * 12 + (start.getMonth() - today.getMonth());
      delay = Math.max(0, j - 1);
    }
    const months = delay + Math.ceil(remaining / Number(g.monthly_contribution));
    const date = new Date(); date.setMonth(date.getMonth() + months);
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  }

  const formFields = useMemo(() => {
    const fields: any[] = [
      { key: 'name', label: form.goal_type === 'Car Fund' ? 'Vehicle Name' : 'Goal Name', type: 'text', placeholder: form.goal_type === 'Car Fund' ? 'e.g., Porsche Cayman' : 'e.g., Emergency Fund' },
      { key: 'goal_type', label: 'Goal Type', type: 'select', options: GOAL_TYPES.map(t => ({ value: t, label: t })) },
      { key: 'linked_account', label: 'Linked Account (auto-pull balance)', type: 'select', options: accountOptions },
      { key: 'linked_rule_id', label: 'Transfer Rule (auto-sync amount & start date)', type: 'select', options: transferRuleOptions },
      { key: 'target_amount', label: form.goal_type === 'Car Fund' ? 'Down Payment Goal' : 'Target Amount', type: 'number', placeholder: '10000', step: '0.01' },
    ];
    // Only show manual current_amount if no linked account
    if (!form.linked_account) {
      fields.push({ key: 'current_amount', label: 'Current Saved', type: 'number', placeholder: '0', step: '0.01' });
    }
    // Hide manual contribution/start when a rule is linked (auto-derived)
    if (!(form as any).linked_rule_id) {
      fields.push({ key: 'monthly_contribution', label: 'Monthly Contribution', type: 'number', placeholder: '500', step: '0.01' });
      fields.push({ key: 'contribution_start_date', label: 'Contributions Start (optional)', type: 'date' });
    }
    fields.push({ key: 'target_date', label: 'Target Date', type: 'date' });
    if (form.goal_type === 'Car Fund') {
      fields.push(
        { key: 'target_price', label: 'Vehicle Target Price', type: 'number', placeholder: '50000', step: '0.01' },
        { key: 'tax_fees', label: 'Tax & Fees', type: 'number', placeholder: '5000', step: '0.01' },
        { key: 'monthly_insurance', label: 'Monthly Insurance', type: 'number', placeholder: '250', step: '0.01' },
        { key: 'expected_apr', label: 'Expected Loan APR %', type: 'number', placeholder: '5.9', step: '0.01' },
        { key: 'loan_term_months', label: 'Loan Term (months)', type: 'number', placeholder: '60' },
      );
    }
    return fields;
  }, [form.goal_type, form.linked_account, accountOptions]);

  if (accountsLoading) return <PageSkeleton />;

  return (
    <div className="py-4 lg:py-6 max-w-6xl mx-auto space-y-6 overflow-x-hidden">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-display font-bold text-xl sm:text-2xl tracking-tight">Goals</h1>
            <InstructionsModal pageTitle="Savings Goals Guide" sections={[
              { title: 'What is this page?', body: 'Track progress toward your financial goals — emergency fund, vacation, down payment, or car purchase. Link goals to real accounts for automatic balance sync.' },
              { title: 'Linked Accounts', body: 'When linked to an account, the goal\'s "current saved" automatically reflects that account balance. "Available after bills" shows the realistic amount after subtracting scheduled outflows.' },
              { title: 'Car Fund', body: 'The Car Fund mode adds vehicle-specific fields like price, APR, loan term, and insurance to give you a complete affordability picture.' },
              { title: 'Target Date', body: 'Set a target date to see estimated completion. The chart projects growth based on your monthly contribution.' },
            ]} />
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">Build your financial runway</p>
        </div>
        <div className="flex flex-col gap-2 w-full sm:w-auto sm:flex-row sm:shrink-0">
          {(isPremium || isDemo || goals.length < 3) ? (
            <button onClick={() => openAdd('Custom')} className="w-full sm:w-auto flex items-center justify-center gap-1.5 bg-primary text-primary-foreground px-3 py-1.5 text-xs font-medium btn-press" style={{ borderRadius: 'var(--radius)' }}><Plus size={12} /> Add Goal</button>
          ) : (
            <Link to="/premium" className="w-full sm:w-auto flex items-center justify-center gap-1.5 bg-primary/20 text-primary px-3 py-1.5 text-xs font-medium btn-press hover:bg-primary/30 transition-colors" style={{ borderRadius: 'var(--radius)' }}><Crown size={12} /> Add Goal</Link>
          )}

          {(isPremium || isDemo) ? (
            <button onClick={() => openAdd('Car Fund')} className="w-full sm:w-auto flex items-center justify-center gap-1.5 border border-border text-foreground px-3 py-1.5 text-xs font-medium btn-press hover:bg-muted/30" style={{ borderRadius: 'var(--radius)' }}><Car size={12} /> Car Fund</button>
          ) : (
            <Link to="/premium" className="w-full sm:w-auto flex items-center justify-center gap-1.5 border border-primary/30 text-primary/70 px-3 py-1.5 text-xs font-medium btn-press hover:bg-primary/5 transition-colors" style={{ borderRadius: 'var(--radius)' }}><Crown size={12} /> Car Fund</Link>
          )}
        </div>
      </div>

      {isDemo && (
        <div className="card-forged p-4 sm:p-5 border-primary/20">
          <div className="flex items-start gap-3 mb-3">
            <div className="shrink-0 w-1.5 h-8 bg-primary rounded-full mt-0.5" />
            <div>
              <p className="text-xs font-semibold text-foreground">Savings goals + Car Fund — track every target in one place</p>
              <p className="text-xs text-muted-foreground mt-0.5">Jordan is building an emergency fund while saving for a car. Goals link to real accounts and auto-sync balances.</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            {[
              { label: 'Emergency Fund', desc: 'Linked to Marcus HYS — the $5,800 balance auto-syncs here. Monthly $300 contribution tracked against the $15,000 target.' },
              { label: 'Car Fund', desc: 'Models the full purchase: $28,000 target, $5,600 down payment goal, 5.9% APR loan. Shows estimated monthly payment after purchase.' },
              { label: 'Linked accounts', desc: 'When an account is linked, "current saved" always reflects the live balance — no manual updates needed.' },
              { label: 'Connects to Forecast', desc: 'Monthly contributions here are deducted in the Forecast before sizing debt payments — goals don\'t compete with the debt engine.' },
            ].map((f, i) => (
              <div key={i} className="flex gap-2 p-2.5 bg-secondary/40 text-xs" style={{ borderRadius: 'var(--radius)' }}>
                <span className="text-primary font-bold shrink-0">→</span>
                <div><span className="font-medium text-foreground">{f.label}: </span><span className="text-muted-foreground">{f.desc}</span></div>
              </div>
            ))}
          </div>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-muted-foreground">All data is fictional.</p>
            <Link to="/auth" className="text-xs font-semibold text-primary hover:underline">Use with your own data →</Link>
          </div>
        </div>
      )}

      <SavingsGrowthChart goals={allGoals} />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="card-forged p-4 text-center"><p className="text-xs text-muted-foreground uppercase">Total Saved</p><p className="text-lg font-display font-bold text-success">{formatCurrency(totalSaved, false)}</p></div>
        <div className="card-forged p-4 text-center"><p className="text-xs text-muted-foreground uppercase">Total Target</p><p className="text-lg font-display font-bold text-foreground">{formatCurrency(totalTarget, false)}</p></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {allGoals.map(g => {
          const pct = Number(g.target_amount) > 0 ? (Number(g.current_amount) / Number(g.target_amount)) * 100 : 0;
          const isCar = g.goal_type === 'Car Fund';
          const car = (g as any).car_data;
          const isLinked = !!(g as any).linked_account && accountMap[(g as any).linked_account];
          const linkedAcct = isLinked ? accountMap[(g as any).linked_account] : null;

          return (
            <div key={g.id} className="card-forged p-4 space-y-3 hover:border-primary/20 transition-colors">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2 min-w-0">
                    {isCar && <Car size={14} className="text-primary" />}
                    <h3 className="text-sm font-semibold break-words">{g.name}</h3>
                    <span className="text-[9px] px-1.5 py-0.5 bg-muted/50 border border-border text-muted-foreground" style={{ borderRadius: 'var(--radius)' }}>{g.goal_type || 'Custom'}</span>
                    {isLinked && (
                      <span className="text-[9px] px-1.5 py-0.5 bg-primary/10 border border-primary/20 text-primary flex items-center gap-1" style={{ borderRadius: 'var(--radius)' }}>
                        <Link2 size={8} /> {linkedAcct?.name}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground break-words leading-relaxed">
                    {(g as any).linked_rule
                      ? <span className="text-primary/80">{formatCurrency(Number(g.monthly_contribution), false)}/mo · via {(g as any).linked_rule.name}</span>
                      : `${formatCurrency(Number(g.monthly_contribution), false)}/mo contribution`
                    }
                    {isLinked && ' · Auto-synced from account'}
                    {(g as any).available_after_outflows != null && (
                      <span className="ml-1 text-muted-foreground">· Available after bills: {formatCurrency((g as any).available_after_outflows, false)}</span>
                    )}
                  </p>
                </div>
                <div className="flex gap-1 shrink-0 self-end sm:self-auto">
                  <button onClick={() => handleDuplicate(g)} className="icon-btn text-muted-foreground hover:text-primary" title="Duplicate"><Copy size={13} /></button>
                  <button onClick={() => openEdit(g)} className="icon-btn text-muted-foreground hover:text-foreground"><Edit2 size={14} /></button>
                  <button onClick={() => handleDelete(g.id)} className={`icon-btn ${deleteConfirm === g.id ? 'text-destructive' : 'text-muted-foreground hover:text-destructive'}`}><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
                <span className="text-lg font-display font-bold text-primary break-words">{formatCurrency(Number(g.current_amount), false)}</span>
                <span className="text-xs text-muted-foreground">of {formatCurrency(Number(g.target_amount), false)}</span>
              </div>
              <ProgressBar value={Number(g.current_amount)} max={Number(g.target_amount)} color={pct >= 100 ? 'success' : 'gold'} />
              <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between text-xs text-muted-foreground">
                <span>{pct.toFixed(0)}% complete</span>
                <span>Est. completion: {estimateCompletion(g)}</span>
              </div>
              {isCar && car && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-border">
                  <div className="text-center"><p className="text-[9px] text-muted-foreground uppercase">Vehicle Price</p><p className="text-xs font-display font-bold">{formatCurrency(Number(car.target_price), false)}</p></div>
                  <div className="text-center"><p className="text-[9px] text-muted-foreground uppercase">Est. Monthly</p><p className="text-xs font-display font-bold text-primary">{formatCurrency(calculateMonthlyPayment(Number(car.target_price) + Number(car.tax_fees) - Number(car.down_payment_goal), Number(car.expected_apr), Number(car.loan_term_months)), true)}</p></div>
                  <div className="text-center"><p className="text-[9px] text-muted-foreground uppercase">Insurance/mo</p><p className="text-xs font-display font-bold">{formatCurrency(Number(car.monthly_insurance), false)}</p></div>
                  <div className="text-center"><p className="text-[9px] text-muted-foreground uppercase">Loan Term</p><p className="text-xs font-display font-bold">{car.loan_term_months} mo</p></div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {allGoals.length === 0 && (
        <div className="card-forged p-12 text-center"><p className="text-sm text-muted-foreground">No savings goals yet.</p><p className="text-xs text-muted-foreground mt-1">Set a target. Build discipline.</p></div>
      )}

      {showForm && (
        <FormModal
          title={editId ? 'Edit Goal' : form.goal_type === 'Car Fund' ? 'New Car Fund Goal' : 'New Savings Goal'}
          fields={formFields}
          values={form}
          onChange={(k, v) => setForm(prev => ({ ...prev, [k]: v }))}
          onSave={handleSave}
          onClose={() => setShowForm(false)}
          saving={add.isPending || update.isPending || updateCarFund.isPending}
          saveLabel={editId ? 'Update Goal' : 'Add Goal'}
        />
      )}
    </div>
  );
}