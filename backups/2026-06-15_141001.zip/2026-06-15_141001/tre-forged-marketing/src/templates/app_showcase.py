"""
App Showcase template — cinematic atmospheric background, centered phone hero,
editorial headline above.

Post JSON fields:
  hook        : large editorial headline (required)
  body        : supporting subtext below headline (optional)
  label       : pill tag e.g. "New Feature" or "Debt Payoff" (optional)
  screenshot  : path to app screenshot PNG/JPG (optional — uses demo screen if missing)
  tagline     : small line above footer (optional)
"""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
from src.templates.base import BaseTemplate, hex_to_rgb, blend, lighten, MARGIN, FOOTER_H


class AppShowcaseTemplate(BaseTemplate):

    def render(self, post: dict, brand: dict, size) -> Image.Image:
        W, H = size
        scale = H / 1080

        # Phone: 60% of available vertical space, horizontally centered
        available_h = H - FOOTER_H
        phone_h = int(available_h * 0.60)
        phone_w = int(phone_h / 2.16)
        phone_x = (W - phone_w) // 2
        phone_y = H - FOOTER_H - phone_h - int(18 * scale)

        # Atmospheric background bakes phone glow in before text is drawn
        img = self._atmospheric_bg(size, brand, phone_x, phone_y, phone_w, phone_h)
        draw = ImageDraw.Draw(img)

        accent = hex_to_rgb(brand["accent_color"])
        bg = hex_to_rgb(brand["bg_color"])
        white = hex_to_rgb(brand["text_color"])
        content_w = W - 2 * MARGIN

        # Font sizes scale with canvas height so story format reads large
        fs = min(scale, 1.45)
        hook_f   = self.font(int(72  * fs), bold=True)
        body_f   = self.font(int(34  * fs))
        label_fs = int(22 * fs)
        tag_fs   = int(24 * fs)

        # ── Text zone (above phone) ────────────────────────────────────────────
        y = int(72 * scale)

        if post.get("label"):
            y = self._draw_label_pill(draw, W, y, scale, post["label"], label_fs, accent, bg)
            y += int(22 * scale)
        else:
            y += int(8 * scale)

        y = self.draw_text_block(
            draw, post["hook"], MARGIN, y, content_w, hook_f, white,
            line_gap=int(8 * scale), align="center",
        )
        y += int(18 * scale)

        if post.get("body"):
            body_color = blend(white, bg, 0.82)
            self.draw_text_block(
                draw, post["body"], MARGIN, y, content_w, body_f, body_color,
                line_gap=int(7 * scale), align="center",
            )

        # ── Phone hero ──────────────────────────────────────────────────────────
        self._draw_phone(img, draw, post.get("screenshot"), phone_x, phone_y, phone_w, phone_h, brand)

        # ── Bottom vignette — melts phone base into footer ─────────────────────
        self._bottom_vignette(img, brand, phone_y + int(phone_h * 0.88), H - FOOTER_H + 6)

        # ── Tagline above footer ────────────────────────────────────────────────
        if post.get("tagline"):
            tag_f = self.font(tag_fs, bold=True)
            tag_color = lighten(accent, 0.42)
            tag_w, _ = self.text_size(draw, post["tagline"], tag_f)
            tag_y = H - FOOTER_H - int(32 * scale)
            if tag_y > phone_y + phone_h + 4:
                draw.text(((W - tag_w) // 2, tag_y), post["tagline"], fill=tag_color, font=tag_f)

        self.draw_footer(draw, size, brand)
        return img

    # ── Label pill ─────────────────────────────────────────────────────────────

    def _draw_label_pill(self, draw, W, y, scale, text, font_size, accent, bg) -> int:
        """Draw a centered rounded pill with accent border. Returns y below the pill."""
        f = self.font(font_size, bold=True)
        tw, th = self.text_size(draw, text.upper(), f)
        pad_x = int(20 * scale)
        pad_y = int(9 * scale)
        pill_w = tw + pad_x * 2
        pill_h = th + pad_y * 2
        pill_x = (W - pill_w) // 2
        fill   = blend(accent, bg, 0.25)
        border = blend(accent, bg, 0.52)
        draw.rounded_rectangle(
            [(pill_x, y), (pill_x + pill_w, y + pill_h)],
            radius=pill_h // 2, fill=fill, outline=border, width=1,
        )
        text_color = lighten(accent, 0.46)
        draw.text((pill_x + pad_x, y + pad_y), text.upper(), fill=text_color, font=f)
        return y + pill_h

    # ── Atmospheric background ─────────────────────────────────────────────────

    def _atmospheric_bg(self, size, brand, phone_x, phone_y, phone_w, phone_h) -> Image.Image:
        W, H = size
        bg_c   = hex_to_rgb(brand.get("bg_color",     "#0D0D0D"))
        accent = hex_to_rgb(brand.get("accent_color", "#C9A84C"))

        # Multi-stop vertical gradient — computed per-row, zero discrete layers,
        # zero hard lines. Smoothstep curve between each stop.
        stops = [
            (0.00, blend(accent, bg_c, 0.44)),  # top: warmest
            (0.28, blend(accent, bg_c, 0.24)),  # upper third
            (0.55, blend(accent, bg_c, 0.09)),  # mid: dim warmth
            (0.78, blend(accent, bg_c, 0.03)),  # lower: nearly bg
            (1.00, bg_c),                         # bottom: pure bg
        ]

        strip = Image.new("RGB", (1, H))
        for row in range(H):
            t = row / (H - 1)
            strip.putpixel((0, row), self._gradient_sample(t, stops))
        base = strip.resize((W, H), Image.NEAREST)

        # Phone area glow — single soft additive layer, oversized so its edges
        # always fall outside the canvas (no visible rectangular boundary)
        glow_w = W * 2
        glow_h = int(phone_h * 2.2)
        glow = Image.new("RGB", (glow_w, glow_h), bg_c)
        ImageDraw.Draw(glow).ellipse(
            [(glow_w // 5, glow_h // 7), (glow_w * 4 // 5, glow_h * 6 // 7)],
            fill=tuple(c * 28 // 100 for c in accent),
        )
        glow = glow.filter(ImageFilter.GaussianBlur(85))
        gx = phone_x + phone_w // 2 - glow_w // 2
        gy = phone_y + phone_h // 2 - glow_h // 2
        self._additive_paste(base, glow, gx, gy)

        return base

    @staticmethod
    def _gradient_sample(t: float, stops: list) -> tuple:
        """Interpolate between gradient stops with smoothstep easing."""
        for i in range(len(stops) - 1):
            t0, c0 = stops[i]
            t1, c1 = stops[i + 1]
            if t <= t1:
                u = (t - t0) / (t1 - t0) if t1 > t0 else 1.0
                u = u * u * (3 - 2 * u)  # smoothstep
                return blend(c1, c0, u)
        return stops[-1][1]

    def _additive_paste(self, base: Image.Image, layer: Image.Image, x: int, y: int) -> None:
        """Additive blend: pixels only get brighter, never darker (clips at 255).
        Oversizing the layer so edges fall outside the canvas eliminates the hard
        rectangular boundary that Image.blend creates at crop boundaries.
        """
        from PIL import ImageChops
        W, H = base.size
        lw, lh = layer.size
        xc = max(0, x)
        yc = max(0, y)
        cx = xc - x
        cy = yc - y
        pw = min(lw - cx, W - xc)
        ph = min(lh - cy, H - yc)
        if pw <= 0 or ph <= 0:
            return
        layer_crop = layer.crop((cx, cy, cx + pw, cy + ph))
        base_crop  = base.crop((xc, yc, xc + pw, yc + ph))
        merged = ImageChops.add(base_crop, layer_crop)
        base.paste(merged, (xc, yc))

    # ── Bottom vignette ────────────────────────────────────────────────────────

    def _bottom_vignette(self, img: Image.Image, brand: dict, y_start: int, y_end: int) -> None:
        """Fade from transparent at y_start to bg_color at y_end."""
        W = img.size[0]
        bg_c = hex_to_rgb(brand.get("bg_color", "#0D0D0D"))
        fade_h = max(1, y_end - y_start)
        # Build gradient mask via 1-pixel strip + resize (fast)
        strip = Image.new("L", (1, fade_h))
        for row in range(fade_h):
            strip.putpixel((0, row), int(255 * (row / fade_h) ** 1.4))
        mask = strip.resize((W, fade_h), Image.BILINEAR)
        img.paste(Image.new("RGB", (W, fade_h), bg_c), (0, y_start), mask=mask)

    # ── Phone frame ───────────────────────────────────────────────────────────

    def _draw_phone(self, img, draw, screenshot_path, x, y, w, h, brand):
        radius = max(32, w // 7)
        border = max(7, w // 36)
        accent = hex_to_rgb(brand.get("accent_color", "#6D28D9"))
        bg_c   = hex_to_rgb(brand.get("bg_color",     "#0D0D0D"))

        # Layered drop shadow (three passes, no blur needed)
        for offset, a in [(9, 0.16), (5, 0.28), (2, 0.38)]:
            shadow = blend((0, 0, 0), bg_c, a)
            draw.rounded_rectangle(
                [(x + offset, y + offset), (x + w + offset, y + h + offset)],
                radius=radius, fill=shadow,
            )

        # Phone body
        draw.rounded_rectangle([(x, y), (x + w, y + h)], radius=radius, fill=(15, 11, 27))

        # Outer accent ring
        draw.rounded_rectangle(
            [(x + 1, y + 1), (x + w - 1, y + h - 1)],
            radius=radius - 1, outline=tuple(c // 4 for c in accent), width=2,
        )

        # Inner subtle edge catch
        draw.rounded_rectangle(
            [(x + 4, y + 4), (x + w - 4, y + h - 4)],
            radius=radius - 4, outline=tuple(c // 10 for c in accent), width=1,
        )

        # Screen area
        sx, sy = x + border, y + border + 10
        sw, sh = w - border * 2, h - border * 2 - 20
        screen_radius = max(radius - 10, 6)

        if screenshot_path and Path(screenshot_path).exists():
            self._paste_screenshot(img, screenshot_path, sx, sy, sw, sh, screen_radius)
        else:
            draw.rounded_rectangle([(sx, sy), (sx + sw, sy + sh)], radius=screen_radius, fill=(5, 3, 16))
            self._draw_demo_screen(draw, sx, sy, sw, sh, brand)

        # Dynamic island pill
        pill_w = int(w * 0.34)
        pill_h = max(10, int(h * 0.016))
        pill_x = sx + sw // 2 - pill_w // 2
        draw.rounded_rectangle(
            [(pill_x, sy + 9), (pill_x + pill_w, sy + 9 + pill_h)],
            radius=pill_h // 2, fill=(8, 5, 16),
        )

    def _paste_screenshot(self, img, path, sx, sy, sw, sh, radius):
        ss = Image.open(path).convert("RGB").resize((sw, sh), Image.LANCZOS)
        mask = Image.new("L", (sw, sh), 0)
        ImageDraw.Draw(mask).rounded_rectangle([(0, 0), (sw - 1, sh - 1)], radius=radius, fill=255)
        img.paste(ss, (sx, sy), mask=mask)

    def _draw_demo_screen(self, draw, x, y, w, h, brand):
        """Forgenta placeholder UI — replaced when real screenshot path is supplied."""
        accent     = hex_to_rgb(brand.get("accent_color", "#6D28D9"))
        white      = (220, 214, 236)
        gray       = (84, 77, 108)
        purple_dim = tuple(c // 3 for c in accent)
        green      = (34, 197, 94)
        red        = (239, 68, 68)

        pad = max(8, w // 18)
        # Vertical rhythm — all gaps proportional to screen height
        u = h / 100  # 1% of screen height
        yy = y + int(5 * u)

        f_xs = self.font(max(8,  w // 30))
        f_sm = self.font(max(10, w // 24))
        f_md = self.font(max(13, w // 18), bold=True)
        f_lg = self.font(max(22, w // 11), bold=True)

        # Status bar
        draw.text((x + pad, yy), "9:41", fill=gray, font=f_xs)
        yy += int(5 * u)

        # App name
        draw.text((x + pad, yy), "FORGENTA", fill=tuple(c * 65 // 100 for c in accent), font=f_xs)
        yy += int(3 * u)

        # Net worth
        draw.text((x + pad, yy), "Net Worth", fill=gray, font=f_sm)
        yy += int(4 * u)
        draw.text((x + pad, yy), "$12,430", fill=white, font=f_lg)
        yy += int(7 * u)

        # Divider
        draw.rectangle([(x + pad, yy), (x + w - pad, yy + 1)], fill=purple_dim)
        yy += int(2.5 * u)

        # Stat cards
        card_w = (w - pad * 3) // 2
        card_h = int(11.5 * u)
        for i, (lbl, val, color) in enumerate([("Debt-Free", "Aug 2027", green), ("Saved/Mo.", "+$340", green)]):
            cx = x + pad + i * (card_w + pad)
            draw.rounded_rectangle([(cx, yy), (cx + card_w, yy + card_h)], radius=5, fill=(13, 9, 26))
            draw.text((cx + 5, yy + 4), lbl, fill=gray, font=f_xs)
            draw.text((cx + 5, yy + card_h // 2), val, fill=color, font=f_md)
        yy += card_h + int(2 * u)

        # Payoff progress bar
        draw.text((x + pad, yy), "Payoff Progress", fill=gray, font=f_xs)
        yy += int(3 * u)
        bar_h = max(4, int(1.2 * u))
        fill_w = int((w - pad * 2) * 0.62)
        draw.rounded_rectangle([(x + pad, yy), (x + w - pad, yy + bar_h)], radius=bar_h // 2, fill=(18, 14, 34))
        draw.rounded_rectangle([(x + pad, yy), (x + pad + fill_w, yy + bar_h)], radius=bar_h // 2, fill=accent)
        yy += bar_h + int(2 * u)

        # Monthly spending chart
        draw.text((x + pad, yy), "Monthly Spend", fill=gray, font=f_xs)
        yy += int(3 * u)
        bars = [0.45, 0.70, 0.38, 1.0, 0.72, 0.85, 0.58]
        bar_area_h = int(12 * u)
        bar_w = (w - pad * 2 - (len(bars) - 1) * 2) // len(bars)
        for i, frac in enumerate(bars):
            bx = x + pad + i * (bar_w + 2)
            bh = int(bar_area_h * frac)
            by = yy + bar_area_h - bh
            color = accent if frac == max(bars) else tuple(c * 48 // 100 for c in accent)
            draw.rounded_rectangle([(bx, by), (bx + bar_w, yy + bar_area_h)], radius=2, fill=color)
        yy += bar_area_h + int(2 * u)

        # Divider
        draw.rectangle([(x + pad, yy), (x + w - pad, yy + 1)], fill=purple_dim)
        yy += int(2.5 * u)

        # Credit cards list
        draw.text((x + pad, yy), "Credit Cards", fill=gray, font=f_xs)
        yy += int(3.5 * u)
        for lbl, bal, color in [("Amex Gold", "$420", red), ("Prime Visa", "$0", green)]:
            draw.text((x + pad, yy), lbl, fill=white, font=f_sm)
            bw, _ = self.text_size(draw, bal, f_sm)
            draw.text((x + w - pad - bw, yy), bal, fill=color, font=f_sm)
            yy += int(4 * u)

        # Divider
        draw.rectangle([(x + pad, yy), (x + w - pad, yy + 1)], fill=purple_dim)
        yy += int(2.5 * u)

        # Monthly surplus row
        draw.text((x + pad, yy), "Surplus This Month", fill=gray, font=f_xs)
        surplus_val = "+$340"
        sw_text, _ = self.text_size(draw, surplus_val, f_md)
        draw.text((x + w - pad - sw_text, yy + 1), surplus_val, fill=green, font=f_md)
        yy += int(5.5 * u)

        # Recent transaction preview
        draw.text((x + pad, yy), "Recent", fill=gray, font=f_xs)
        yy += int(3.5 * u)
        for desc, amt, color in [("Trader Joe's", "-$67", (220, 214, 236)), ("Paycheck", "+$2,840", green)]:
            draw.text((x + pad, yy), desc, fill=white, font=f_xs)
            aw, _ = self.text_size(draw, amt, f_xs)
            draw.text((x + w - pad - aw, yy), amt, fill=color, font=f_xs)
            yy += int(3.8 * u)
